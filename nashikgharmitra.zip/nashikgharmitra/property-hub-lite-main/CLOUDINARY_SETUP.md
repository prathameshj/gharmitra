# Cloudinary Image Upload Integration

## Overview

NashikGharMitra uses **Cloudinary** for image storage and delivery, enabling 100+ users with 300+ property images on Replit's **free tier** without exceeding storage limits.

### Why Cloudinary?

- **Free Tier**: 25 GB storage + monthly credits
- **CDN Delivery**: Images served globally via Cloudinary's CDN
- **Auto Compression**: Automatic quality optimization (target 150-250 KB/image)
- **Responsive Images**: Built-in transformations for different devices
- **No Local Storage**: Keeps Replit file storage at 0.5 GB clean

---

## Storage Calculation

### For 100 Users with 300 Images:

| Item | Calculation | Result |
|------|------------|--------|
| Images per listing | 3 images | 3 |
| Total images | 100 users × 3 | **300 images** |
| Average size per image | Auto-compressed | **150-250 KB** |
| Total storage needed | 300 × 200 KB | **~60 MB** |
| Database size (URLs) | 300 × 100 bytes | **~30 KB** |
| Cloudinary free limit | - | **25 GB** |
| **Safety margin** | 60 MB / 25 GB | **0.24%** ✅ |

### What This Means:
- You can support **500+ users** (1,500 images) before using 1% of Cloudinary free tier
- Database storage remains minimal (only URLs stored)
- No risk of exceeding any limits

---

## Setup Instructions

### 1. Get Cloudinary Credentials

1. Go to [cloudinary.com](https://cloudinary.com)
2. Sign up for **free account**
3. Go to **Settings → API Keys**
4. Copy:
   - **CLOUDINARY_CLOUD_NAME** (e.g., `d1a2b3c4d`)
   - **CLOUDINARY_API_KEY** (e.g., `123456789`)
   - **CLOUDINARY_API_SECRET** (e.g., `abc123def456...`)

### 2. Add to Replit Secrets

✅ **Already done!** The secrets are stored in Replit:
- `CLOUDINARY_CLOUD_NAME`
- `CLOUDINARY_API_KEY`
- `CLOUDINARY_API_SECRET`

### 3. Configure Upload Preset (Optional but Recommended)

1. In Cloudinary Dashboard → Settings → Upload
2. Scroll to "Upload presets"
3. Click "Add upload preset"
4. Set to **Unsigned** (safe for client-side uploads)
5. Name it: `nashik_properties`
6. Save

---

## How Image Upload Works

### Step 1: Client-Side Validation
```typescript
// File type check: only JPG, PNG, WebP
// Size check: max 10 MB before compression
```

### Step 2: Client-Side Compression
```typescript
// Target: 150-250 KB per image
// Max dimensions: 1200×900 pixels
// Quality: 70% JPEG compression
```

### Step 3: Upload to Cloudinary
```typescript
// Direct upload to Cloudinary CDN
// Folder structure: nashik_properties/{userId}/{timestamp}.jpg
// Returns HTTPS URL (secure_url)
```

### Step 4: Store URL in Database
```typescript
// Save only the Cloudinary URL in PostgreSQL
// Database stores: images: ["https://res.cloudinary.com/..."]
// No image data stored locally
```

### Example Response:
```json
{
  "success": true,
  "url": "https://res.cloudinary.com/xyz/image/upload/v1234567890/nashik_properties/user123/1640123456.jpg",
  "publicId": "nashik_properties/user123/1640123456",
  "size": 195842
}
```

---

## API Reference

### `uploadToCloudinary(file, folder)`
Upload a single image
```typescript
import { uploadToCloudinary } from '@/services/cloudinaryService';

const result = await uploadToCloudinary(file, 'nashik_properties/user123');
if (result.success) {
  console.log('Image URL:', result.url);
}
```

### `validateImage(file)`
Validate file type and size
```typescript
const validation = validateImage(file);
if (!validation.valid) {
  console.error(validation.error);
}
```

### `getOptimizedImageUrl(publicId, width, height)`
Generate responsive image URLs
```typescript
// Thumbnail: 200×150 px
const thumb = getThumbnailUrl('nashik_properties/user123/image.jpg');

// Custom size: 600×400 px
const optimized = getOptimizedImageUrl('nashik_properties/user123/image.jpg', 600, 400);
```

### `batchUploadImages(files, folder)`
Upload multiple images
```typescript
const results = await batchUploadImages([file1, file2, file3], 'nashik_properties/user123');
```

---

## Database Schema

Property images stored as URL array:
```sql
CREATE TABLE properties (
  id uuid PRIMARY KEY,
  title text,
  images text[] REFERENCES cloudinary -- Array of HTTPS URLs
);
```

Example:
```typescript
{
  id: '123abc',
  title: 'Beautiful 3BHK Apartment',
  images: [
    'https://res.cloudinary.com/xyz/image/upload/.../image1.jpg',
    'https://res.cloudinary.com/xyz/image/upload/.../image2.jpg',
    'https://res.cloudinary.com/xyz/image/upload/.../image3.jpg'
  ]
}
```

---

## File Organization

```
src/
├── services/
│   └── cloudinaryService.ts       # Upload functions & utilities
│       ├── validateImage()         # Check file type & size
│       ├── compressImage()         # Client-side compression
│       ├── uploadToCloudinary()    # Main upload function
│       ├── getOptimizedImageUrl()  # Generate responsive URLs
│       └── getThumbnailUrl()       # Quick thumbnail generation
│
├── pages/
│   └── PostProperty.tsx            # Property posting form
│       ├── handleImageSelect()     # File input handler
│       ├── handleDrop()            # Drag & drop handler
│       └── uploadImages()          # Batch upload to Cloudinary
│
└── integrations/
    └── supabase/
        └── types.ts               # Database schema (images: string[])
```

---

## Free-Tier Limits & Safety

| Feature | Free Tier | Our Usage | Status |
|---------|-----------|-----------|--------|
| Storage | 25 GB | ~60 MB (100 users) | ✅ Safe |
| Bandwidth | Monthly credits | Auto-optimized | ✅ Safe |
| Image formats | Any | JPG, PNG, WebP | ✅ Supported |
| Transformations | Unlimited | w/h/quality | ✅ Included |
| Minimum billing | 7 days | N/A | ✅ Free |

### What Happens If You Exceed Free Tier?

1. **First 25 GB**: Completely free
2. **Beyond 25 GB**: Pay-as-you-go billing
   - Storage: $0.50 per GB/month
   - Bandwidth: $0.125 per GB
3. **You'll be notified** before any charges apply

**Our safety margin**: Supporting 500+ users before needing upgrades

---

## Optimization Tips

### 1. Auto Image Compression
Already enabled in `cloudinaryService.ts`:
- Client-side: 70% JPEG quality
- Server-side: Auto optimization via Cloudinary transformations

### 2. Responsive Images
Use Cloudinary transformations for different devices:
```typescript
// Desktop: 1200×900
// Tablet: 600×400
// Mobile: 300×200
```

### 3. Batch Uploads
Upload all 3 images in parallel (faster):
```typescript
const urls = await Promise.all(
  [file1, file2, file3].map(f => uploadToCloudinary(f, folder))
);
```

### 4. Caching
Images are cached by browsers automatically:
- Cache control headers: 1 year
- CDN edge caching: Cloudinary handles

---

## Troubleshooting

### "Cloudinary configuration missing"
- Check if `CLOUDINARY_CLOUD_NAME` environment variable is set
- Verify secrets in Replit Settings → Secrets

### "Failed to upload image"
- Check internet connection
- Verify file is JPG, PNG, or WebP
- Ensure file size < 10 MB

### "Images not loading"
- Check if URL is HTTPS (should be)
- Verify Cloudinary public folder permissions
- Clear browser cache and refresh

---

## Next Steps

1. ✅ Cloudinary service is ready to use
2. ✅ PostProperty form integrated
3. Create property detail page to display images
4. Add image gallery component for multiple images
5. Implement lazy loading for better performance

---

## Support

For Cloudinary help: https://cloudinary.com/documentation
For React integration: See `src/services/cloudinaryService.ts`
