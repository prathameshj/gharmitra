-- Allow admins to update any property
CREATE POLICY "Admins can update any property" 
ON public.properties 
FOR UPDATE 
USING (has_role(auth.uid(), 'admin'));

-- Allow admins to delete any property
CREATE POLICY "Admins can delete any property" 
ON public.properties 
FOR DELETE 
USING (has_role(auth.uid(), 'admin'));

-- Create ads table for admin-managed advertisements
CREATE TABLE public.ads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  image_url TEXT,
  link_url TEXT,
  placement TEXT NOT NULL DEFAULT 'homepage',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on ads
ALTER TABLE public.ads ENABLE ROW LEVEL SECURITY;

-- Anyone can view active ads
CREATE POLICY "Anyone can view active ads" 
ON public.ads 
FOR SELECT 
USING (is_active = true);

-- Admins can manage all ads
CREATE POLICY "Admins can manage ads" 
ON public.ads 
FOR ALL 
USING (has_role(auth.uid(), 'admin'));

-- Create trigger for updated_at
CREATE TRIGGER update_ads_updated_at
BEFORE UPDATE ON public.ads
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Allow admins to view all ad inquiries
CREATE POLICY "Admins can view all ad inquiries"
ON public.ad_inquiries
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

-- Allow admins to update ad inquiry status
CREATE POLICY "Admins can update ad inquiries"
ON public.ad_inquiries
FOR UPDATE
USING (has_role(auth.uid(), 'admin'));