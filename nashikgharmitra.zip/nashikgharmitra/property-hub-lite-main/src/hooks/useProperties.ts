import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface Property {
  id: string;
  title: string;
  description: string | null;
  property_type: string;
  listing_type: string;
  price: number;
  bedrooms: number | null;
  bathrooms: number | null;
  area: number | null;
  address: string;
  city: string;
  state: string | null;
  pincode: string | null;
  amenities: string[] | null;
  images: string[] | null;
  is_featured: boolean | null;
  is_boosted: boolean | null;
  is_sold: boolean | null;
  boost_expires_at: string | null;
  user_id: string;
  created_at: string;
  updated_at: string;
}

export const useProperties = (options?: {
  featured?: boolean;
  boosted?: boolean;
  limit?: number;
  excludeSold?: boolean;
}) => {
  return useQuery({
    queryKey: ['properties', options],
    queryFn: async () => {
      let query = supabase
        .from('properties')
        .select('*')
        .order('created_at', { ascending: false });

      if (options?.excludeSold !== false) {
        query = query.or('is_sold.is.null,is_sold.eq.false');
      }

      if (options?.featured) {
        query = query.eq('is_featured', true);
      }

      if (options?.boosted) {
        query = query.eq('is_boosted', true);
      }

      if (options?.limit) {
        query = query.limit(options.limit);
      }

      const { data, error } = await query;

      if (error) throw error;
      return data as Property[];
    },
  });
};

export const useProperty = (id: string) => {
  return useQuery({
    queryKey: ['property', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('properties')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      return data as Property;
    },
    enabled: !!id,
  });
};

export const useFeaturedProperties = (limit = 4) => {
  return useQuery({
    queryKey: ['featured-properties', limit],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('properties')
        .select('*')
        .or('is_featured.eq.true,is_boosted.eq.true')
        .or('is_sold.is.null,is_sold.eq.false')
        .order('is_boosted', { ascending: false })
        .order('created_at', { ascending: false })
        .limit(limit);

      if (error) throw error;
      return data as Property[];
    },
  });
};

export const useRecentProperties = (limit = 6) => {
  return useQuery({
    queryKey: ['recent-properties', limit],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('properties')
        .select('*')
        .or('is_sold.is.null,is_sold.eq.false')
        .order('created_at', { ascending: false })
        .limit(limit);

      if (error) throw error;
      return data as Property[];
    },
  });
};