export interface Property {
  id: string;
  title: string;
  type: 'sale' | 'rent';
  propertyType: 'apartment' | 'house' | 'villa' | 'plot' | 'commercial' | 'office';
  price: number;
  area: number;
  bedrooms: number;
  bathrooms: number;
  location: string;
  city: string;
  image: string;
  images: string[];
  description: string;
  amenities: string[];
  postedDate: string;
  featured: boolean;
  verified: boolean;
  owner: {
    name: string;
    phone: string;
    type: 'owner' | 'agent' | 'builder';
  };
}

export const mockProperties: Property[] = [
  {
    id: '1',
    title: 'Luxury 3BHK Apartment with Sea View',
    type: 'sale',
    propertyType: 'apartment',
    price: 15000000,
    area: 1800,
    bedrooms: 3,
    bathrooms: 3,
    location: 'Bandra West',
    city: 'Mumbai',
    image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&h=600&fit=crop',
    ],
    description: 'Stunning sea-facing apartment with premium finishes, modular kitchen, and 24/7 security.',
    amenities: ['Swimming Pool', 'Gym', 'Parking', 'Security', 'Power Backup', 'Lift'],
    postedDate: '2024-01-15',
    featured: true,
    verified: true,
    owner: { name: 'Rahul Sharma', phone: '+91 98765 43210', type: 'owner' },
  },
  {
    id: '2',
    title: 'Spacious 4BHK Independent House',
    type: 'sale',
    propertyType: 'house',
    price: 25000000,
    area: 3200,
    bedrooms: 4,
    bathrooms: 4,
    location: 'Koramangala',
    city: 'Bangalore',
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&h=600&fit=crop',
    ],
    description: 'Beautiful independent house with garden, modern architecture, and premium interiors.',
    amenities: ['Garden', 'Parking', 'Security', 'Power Backup', 'Terrace'],
    postedDate: '2024-01-14',
    featured: true,
    verified: true,
    owner: { name: 'Priya Builders', phone: '+91 98765 43211', type: 'builder' },
  },
  {
    id: '3',
    title: 'Modern 2BHK for Rent Near Metro',
    type: 'rent',
    propertyType: 'apartment',
    price: 35000,
    area: 1100,
    bedrooms: 2,
    bathrooms: 2,
    location: 'Sector 62',
    city: 'Noida',
    image: 'https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=800&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=800&h=600&fit=crop',
    ],
    description: 'Well-maintained apartment near metro station, ideal for working professionals.',
    amenities: ['Gym', 'Parking', 'Security', 'Power Backup', 'Lift', 'Club House'],
    postedDate: '2024-01-13',
    featured: false,
    verified: true,
    owner: { name: 'Amit Kumar', phone: '+91 98765 43212', type: 'owner' },
  },
  {
    id: '4',
    title: 'Premium Villa with Private Pool',
    type: 'sale',
    propertyType: 'villa',
    price: 45000000,
    area: 5000,
    bedrooms: 5,
    bathrooms: 6,
    location: 'Jubilee Hills',
    city: 'Hyderabad',
    image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1613977257363-707ba9348227?w=800&h=600&fit=crop',
    ],
    description: 'Exquisite villa with private pool, home theater, and landscaped gardens.',
    amenities: ['Private Pool', 'Garden', 'Home Theater', 'Parking', 'Security', 'Gym'],
    postedDate: '2024-01-12',
    featured: true,
    verified: true,
    owner: { name: 'Sunrise Properties', phone: '+91 98765 43213', type: 'agent' },
  },
  {
    id: '5',
    title: 'Commercial Office Space in IT Hub',
    type: 'rent',
    propertyType: 'office',
    price: 150000,
    area: 2500,
    bedrooms: 0,
    bathrooms: 2,
    location: 'Whitefield',
    city: 'Bangalore',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&h=600&fit=crop',
    ],
    description: 'Ready-to-move office space with all modern amenities in prime IT corridor.',
    amenities: ['Parking', 'Security', 'Power Backup', 'Lift', 'Cafeteria', 'Conference Room'],
    postedDate: '2024-01-11',
    featured: false,
    verified: true,
    owner: { name: 'Tech Realty', phone: '+91 98765 43214', type: 'agent' },
  },
  {
    id: '6',
    title: 'Residential Plot in Gated Community',
    type: 'sale',
    propertyType: 'plot',
    price: 8000000,
    area: 2400,
    bedrooms: 0,
    bathrooms: 0,
    location: 'Sarjapur Road',
    city: 'Bangalore',
    image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&h=600&fit=crop',
    ],
    description: 'Prime plot in gated community with approved layout and all amenities.',
    amenities: ['Gated Community', 'Club House', 'Park', 'Security'],
    postedDate: '2024-01-10',
    featured: false,
    verified: true,
    owner: { name: 'Land Developers', phone: '+91 98765 43215', type: 'builder' },
  },
  {
    id: '7',
    title: 'Cozy 1BHK Studio Apartment',
    type: 'rent',
    propertyType: 'apartment',
    price: 18000,
    area: 550,
    bedrooms: 1,
    bathrooms: 1,
    location: 'Andheri East',
    city: 'Mumbai',
    image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&h=600&fit=crop',
    ],
    description: 'Fully furnished studio apartment, perfect for bachelors or young couples.',
    amenities: ['Furnished', 'Parking', 'Security', 'Lift'],
    postedDate: '2024-01-09',
    featured: false,
    verified: false,
    owner: { name: 'Neha Patel', phone: '+91 98765 43216', type: 'owner' },
  },
  {
    id: '8',
    title: 'Retail Shop in Shopping Complex',
    type: 'sale',
    propertyType: 'commercial',
    price: 12000000,
    area: 800,
    bedrooms: 0,
    bathrooms: 1,
    location: 'MG Road',
    city: 'Pune',
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&h=600&fit=crop',
    ],
    description: 'Prime retail space with high footfall in established shopping complex.',
    amenities: ['Parking', 'Security', 'Power Backup', 'Lift'],
    postedDate: '2024-01-08',
    featured: true,
    verified: true,
    owner: { name: 'Commercial Experts', phone: '+91 98765 43217', type: 'agent' },
  },
];

// Re-export from Nashik-specific areas file
export { nashikAreas as cities } from './nashikAreas';
export const propertyTypes = ['Apartment', 'House', 'Villa', 'Plot', 'Commercial', 'Office'];
