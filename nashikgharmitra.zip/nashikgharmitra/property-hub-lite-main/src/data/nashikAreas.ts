// Nashik District Areas - Comprehensive list for local real estate
export const nashikAreas = [
  // Nashik City Areas
  'Adgaon',
  'Ambad',
  'Anand Nagar',
  'Ashok Nagar',
  'Ashok Stambh',
  'Bhagur',
  'Bhosala Military School',
  'Canada Corner',
  'CBS',
  'Chandak Circle',
  'Cidco',
  'College Road',
  'Deolali',
  'Deolali Camp',
  'Deolali Gaon',
  'Dwarka',
  'Eklahare',
  'Gangapur',
  'Gangapur Road',
  'Ganjmal',
  'Govind Nagar',
  'Govindnagar',
  'Harsul',
  'Hirawadi',
  'Indira Nagar',
  'Indiranagar',
  'Jail Road',
  'Kamatwade',
  'Kathe Galli',
  'Konark Nagar',
  'Lekha Nagar',
  'Makhamalganj',
  'Malegaon',
  'Makhmalabad',
  'Meri Colony',
  'MIDC Ambad',
  'MIDC Satpur',
  'Model Colony',
  'Mumbai Naka',
  'Nashik Road',
  'New Cidco',
  'Nimani',
  'Old Agra Road',
  'Old Gangapur Naka',
  'Panchavati',
  'Panchvati',
  'Pandit Colony',
  'Pathardi Phata',
  'Pawar Nagar',
  'Peth Road',
  'Pipeline Road',
  'Prasad Circle',
  'Rajwada',
  'Ram Wadi',
  'Raviwar Karanja',
  'Sarda Circle',
  'Satpur',
  'Shalimar',
  'Shivaji Nagar',
  'Shramik Nagar',
  'Sinnaar Phata',
  'Tidke Colony',
  'Trimurti Chowk',
  'Trimbak Road',
  'Upnagar',
  'Vihitgaon',
  'Wadala Gaon',
  'Wadner Nashik',
  
  // Nashik District Talukas
  'Baglan',
  'Chandwad',
  'Dindori',
  'Igatpuri',
  'Kalwan',
  'Nandgaon',
  'Niphad',
  'Peint',
  'Sinnar',
  'Surgana',
  'Trimbakeshwar',
  'Yeola',
  
  // Major Villages/Towns
  'Manmad',
  'Lasalgaon',
  'Niphad Town',
  'Ozar',
  'Pimpalgaon Baswant',
  'Satana',
  'Vinchur',
  'Wadivarhe',
].sort();

// Property types with SEO-friendly slugs
export const propertyTypes = [
  { label: 'Apartment', value: 'apartment', slug: 'apartments' },
  { label: 'House', value: 'house', slug: 'houses' },
  { label: 'Villa', value: 'villa', slug: 'villas' },
  { label: 'Plot', value: 'plot', slug: 'plots' },
  { label: 'Commercial', value: 'commercial', slug: 'commercial' },
  { label: 'Office', value: 'office', slug: 'offices' },
];

// Listing types with SEO-friendly slugs
export const listingTypes = [
  { label: 'For Sale', value: 'sale', slug: 'for-sale' },
  { label: 'For Rent', value: 'rent', slug: 'for-rent' },
];

// BHK types for SEO routes
export const bhkTypes = [
  { label: '1 BHK', value: 1, slug: '1bhk' },
  { label: '2 BHK', value: 2, slug: '2bhk' },
  { label: '3 BHK', value: 3, slug: '3bhk' },
  { label: '4 BHK', value: 4, slug: '4bhk' },
  { label: '5+ BHK', value: 5, slug: '5bhk-plus' },
];

// Helper to create SEO-friendly URL slug
export const createSlug = (text: string): string => {
  return text
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '')
    .replace(/-+/g, '-')
    .trim();
};

// Generate SEO route for a property
export const generatePropertyRoute = (
  area: string,
  propertyType?: string,
  listingType?: string,
  bhk?: number
): string => {
  const areaSlug = createSlug(area);
  let route = `/nashik/${areaSlug}`;
  
  if (propertyType) {
    const type = propertyTypes.find(t => t.value === propertyType);
    if (type) {
      route += `/${type.slug}`;
    }
  }
  
  if (listingType) {
    const listing = listingTypes.find(l => l.value === listingType);
    if (listing) {
      route += `-${listing.slug}`;
    }
  }
  
  if (bhk) {
    const bhkType = bhkTypes.find(b => b.value === bhk);
    if (bhkType) {
      route = `/nashik/${areaSlug}/${bhkType.slug}-${listingType === 'rent' ? 'for-rent' : 'for-sale'}`;
    }
  }
  
  return route;
};

// Parse SEO route back to filters
export const parsePropertyRoute = (path: string): {
  area?: string;
  propertyType?: string;
  listingType?: string;
  bhk?: number;
} => {
  const parts = path.replace('/nashik/', '').split('/');
  const result: ReturnType<typeof parsePropertyRoute> = {};
  
  if (parts[0]) {
    // Find matching area (case-insensitive)
    const areaMatch = nashikAreas.find(
      a => createSlug(a) === parts[0]
    );
    result.area = areaMatch || parts[0].replace(/-/g, ' ');
  }
  
  if (parts[1]) {
    const segment = parts[1];
    
    // Check for BHK pattern (e.g., "1bhk-for-sale")
    const bhkMatch = segment.match(/^(\d)bhk(-plus)?-(for-sale|for-rent)$/);
    if (bhkMatch) {
      result.bhk = parseInt(bhkMatch[1]);
      result.listingType = bhkMatch[3] === 'for-rent' ? 'rent' : 'sale';
    } else {
      // Check for property type pattern (e.g., "apartments-for-sale")
      for (const type of propertyTypes) {
        if (segment.startsWith(type.slug)) {
          result.propertyType = type.value;
          break;
        }
      }
      
      // Check for listing type
      if (segment.includes('for-sale')) {
        result.listingType = 'sale';
      } else if (segment.includes('for-rent')) {
        result.listingType = 'rent';
      }
    }
  }
  
  return result;
};

// Export cities for backward compatibility
export const cities = nashikAreas;
