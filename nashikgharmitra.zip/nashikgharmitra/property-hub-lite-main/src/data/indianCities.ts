// Comprehensive list of Indian cities organized by state/territory

export const indianCities = [
  // Andhra Pradesh
  'Visakhapatnam', 'Vijayawada', 'Guntur', 'Nellore', 'Kurnool', 'Kadapa', 'Rajahmundry', 'Kakinada', 'Tirupati', 'Anantapur', 'Eluru', 'Ongole', 'Nandyal', 'Machilipatnam', 'Adoni', 'Tenali', 'Proddatur', 'Chittoor', 'Hindupur', 'Srikakulam',
  
  // Arunachal Pradesh
  'Itanagar', 'Naharlagun', 'Pasighat', 'Tawang', 'Ziro', 'Bomdila', 'Aalo', 'Tezu', 'Changlang',
  
  // Assam
  'Guwahati', 'Silchar', 'Dibrugarh', 'Jorhat', 'Nagaon', 'Tinsukia', 'Tezpur', 'Bongaigaon', 'Dhubri', 'Diphu', 'North Lakhimpur', 'Sivasagar', 'Goalpara', 'Karimganj',
  
  // Bihar
  'Patna', 'Gaya', 'Bhagalpur', 'Muzaffarpur', 'Purnia', 'Darbhanga', 'Bihar Sharif', 'Arrah', 'Begusarai', 'Katihar', 'Munger', 'Chhapra', 'Sasaram', 'Hajipur', 'Bettiah', 'Motihari', 'Saharsa', 'Siwan', 'Dehri', 'Buxar',
  
  // Chhattisgarh
  'Raipur', 'Bhilai', 'Bilaspur', 'Korba', 'Durg', 'Rajnandgaon', 'Raigarh', 'Jagdalpur', 'Ambikapur', 'Dhamtari', 'Mahasamund', 'Kawardha',
  
  // Goa
  'Panaji', 'Margao', 'Vasco da Gama', 'Mapusa', 'Ponda', 'Bicholim', 'Curchorem', 'Canacona', 'Sanquelim', 'Cuncolim',
  
  // Gujarat
  'Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Bhavnagar', 'Jamnagar', 'Junagadh', 'Gandhinagar', 'Gandhidham', 'Anand', 'Nadiad', 'Navsari', 'Morbi', 'Porbandar', 'Bharuch', 'Godhra', 'Valsad', 'Vapi', 'Palanpur', 'Bhuj', 'Surendranagar', 'Mehsana',
  
  // Haryana
  'Faridabad', 'Gurgaon', 'Panipat', 'Ambala', 'Yamunanagar', 'Rohtak', 'Hisar', 'Karnal', 'Sonipat', 'Panchkula', 'Bhiwani', 'Sirsa', 'Rewari', 'Palwal', 'Kurukshetra', 'Jind', 'Kaithal', 'Thanesar', 'Bahadurgarh', 'Narnaul',
  
  // Himachal Pradesh
  'Shimla', 'Dharamshala', 'Manali', 'Solan', 'Mandi', 'Kullu', 'Bilaspur', 'Hamirpur', 'Una', 'Palampur', 'Nahan', 'Sundernagar', 'Chamba', 'Paonta Sahib', 'Baddi',
  
  // Jharkhand
  'Ranchi', 'Jamshedpur', 'Dhanbad', 'Bokaro', 'Hazaribagh', 'Deoghar', 'Giridih', 'Ramgarh', 'Medininagar', 'Phusro', 'Dumka', 'Chaibasa', 'Chirkunda',
  
  // Karnataka
  'Bangalore', 'Mysore', 'Mangalore', 'Hubli', 'Belgaum', 'Gulbarga', 'Davangere', 'Bellary', 'Shimoga', 'Tumkur', 'Bijapur', 'Raichur', 'Hassan', 'Udupi', 'Hospet', 'Gadag', 'Chitradurga', 'Kolar', 'Mandya', 'Chikmagalur', 'Bagalkot', 'Bidar',
  
  // Kerala
  'Thiruvananthapuram', 'Kochi', 'Kozhikode', 'Thrissur', 'Kollam', 'Kannur', 'Palakkad', 'Alappuzha', 'Malappuram', 'Kottayam', 'Kasaragod', 'Pathanamthitta', 'Idukki', 'Wayanad', 'Ernakulam',
  
  // Madhya Pradesh
  'Bhopal', 'Indore', 'Jabalpur', 'Gwalior', 'Ujjain', 'Sagar', 'Dewas', 'Satna', 'Ratlam', 'Rewa', 'Murwara', 'Singrauli', 'Burhanpur', 'Khandwa', 'Bhind', 'Chhindwara', 'Guna', 'Shivpuri', 'Vidisha', 'Damoh', 'Mandsaur', 'Khargone', 'Neemuch', 'Pithampur', 'Hoshangabad', 'Itarsi',
  
  // Maharashtra
  'Mumbai', 'Pune', 'Nagpur', 'Thane', 'Nashik', 'Aurangabad', 'Solapur', 'Kolhapur', 'Amravati', 'Navi Mumbai', 'Sangli', 'Malegaon', 'Akola', 'Latur', 'Dhule', 'Ahmednagar', 'Chandrapur', 'Parbhani', 'Jalgaon', 'Bhiwandi', 'Panvel', 'Satara', 'Beed', 'Yavatmal', 'Osmanabad', 'Nanded', 'Ratnagiri', 'Wardha', 'Gondia', 'Kalyan',
  
  // Manipur
  'Imphal', 'Thoubal', 'Bishnupur', 'Churachandpur', 'Kakching', 'Senapati',
  
  // Meghalaya
  'Shillong', 'Tura', 'Jowai', 'Nongstoin', 'Williamnagar', 'Baghmara',
  
  // Mizoram
  'Aizawl', 'Lunglei', 'Champhai', 'Saiha', 'Kolasib', 'Serchhip', 'Lawngtlai',
  
  // Nagaland
  'Kohima', 'Dimapur', 'Mokokchung', 'Tuensang', 'Wokha', 'Zunheboto', 'Mon',
  
  // Odisha
  'Bhubaneswar', 'Cuttack', 'Rourkela', 'Berhampur', 'Sambalpur', 'Puri', 'Balasore', 'Baripada', 'Bhadrak', 'Jharsuguda', 'Jeypore', 'Angul', 'Bargarh', 'Paradip', 'Koraput',
  
  // Punjab
  'Ludhiana', 'Amritsar', 'Jalandhar', 'Patiala', 'Bathinda', 'Mohali', 'Hoshiarpur', 'Pathankot', 'Moga', 'Batala', 'Abohar', 'Malerkotla', 'Khanna', 'Phagwara', 'Muktsar', 'Barnala', 'Rajpura', 'Firozpur', 'Kapurthala', 'Zirakpur',
  
  // Rajasthan
  'Jaipur', 'Jodhpur', 'Kota', 'Bikaner', 'Ajmer', 'Udaipur', 'Bhilwara', 'Alwar', 'Bharatpur', 'Sikar', 'Pali', 'Sri Ganganagar', 'Kishangarh', 'Beawar', 'Hanumangarh', 'Dhaulpur', 'Chittorgarh', 'Tonk', 'Jaisalmer', 'Barmer', 'Nagaur', 'Jhunjhunu', 'Churu', 'Bundi', 'Jhalawar', 'Banswara', 'Dungarpur', 'Rajsamand',
  
  // Sikkim
  'Gangtok', 'Namchi', 'Mangan', 'Gyalshing', 'Rangpo', 'Singtam', 'Jorethang',
  
  // Tamil Nadu
  'Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem', 'Tirunelveli', 'Erode', 'Vellore', 'Thoothukkudi', 'Dindigul', 'Thanjavur', 'Ranipet', 'Sivakasi', 'Karur', 'Nagercoil', 'Hosur', 'Tiruvannamalai', 'Pollachi', 'Rajapalayam', 'Kumbakonam', 'Cuddalore', 'Tiruppur', 'Ambur', 'Kanchipuram', 'Virudhunagar',
  
  // Telangana
  'Hyderabad', 'Warangal', 'Nizamabad', 'Karimnagar', 'Ramagundam', 'Khammam', 'Mahbubnagar', 'Nalgonda', 'Adilabad', 'Suryapet', 'Miryalaguda', 'Siddipet', 'Mancherial', 'Jagtial', 'Nirmal',
  
  // Tripura
  'Agartala', 'Dharmanagar', 'Udaipur', 'Kailashahar', 'Belonia', 'Ambassa', 'Khowai', 'Sabroom',
  
  // Uttar Pradesh
  'Lucknow', 'Kanpur', 'Ghaziabad', 'Agra', 'Varanasi', 'Meerut', 'Allahabad', 'Bareilly', 'Aligarh', 'Moradabad', 'Saharanpur', 'Gorakhpur', 'Noida', 'Firozabad', 'Jhansi', 'Muzaffarnagar', 'Mathura', 'Rampur', 'Shahjahanpur', 'Farrukhabad', 'Ayodhya', 'Maunath Bhanjan', 'Hapur', 'Etawah', 'Mirzapur', 'Bulandshahr', 'Sambhal', 'Amroha', 'Hardoi', 'Fatehpur', 'Raebareli', 'Orai', 'Sitapur', 'Bahraich', 'Modinagar', 'Unnao', 'Jaunpur', 'Lakhimpur', 'Hathras', 'Banda', 'Greater Noida',
  
  // Uttarakhand
  'Dehradun', 'Haridwar', 'Roorkee', 'Haldwani', 'Kashipur', 'Rudrapur', 'Rishikesh', 'Pithoragarh', 'Almora', 'Mussoorie', 'Nainital', 'Kotdwar', 'Ramnagar', 'Pauri', 'Tehri',
  
  // West Bengal
  'Kolkata', 'Howrah', 'Durgapur', 'Asansol', 'Siliguri', 'Bardhaman', 'Malda', 'Baharampur', 'Kharagpur', 'Haldia', 'Darjeeling', 'Krishnanagar', 'Jalpaiguri', 'Bankura', 'Midnapore', 'Raiganj', 'Barrackpore', 'Habra', 'Chandannagar', 'Kalyani', 'Cooch Behar',
  
  // Union Territories
  // Delhi
  'New Delhi', 'Delhi',
  
  // Chandigarh
  'Chandigarh',
  
  // Puducherry
  'Puducherry', 'Karaikal', 'Mahe', 'Yanam',
  
  // Andaman and Nicobar Islands
  'Port Blair',
  
  // Dadra and Nagar Haveli and Daman and Diu
  'Silvassa', 'Daman', 'Diu',
  
  // Jammu and Kashmir
  'Srinagar', 'Jammu', 'Anantnag', 'Baramulla', 'Sopore', 'Kupwara', 'Pulwama', 'Kathua', 'Udhampur', 'Poonch', 'Rajouri',
  
  // Ladakh
  'Leh', 'Kargil',
  
  // Lakshadweep
  'Kavaratti',
].sort();

// Export the old cities array for backward compatibility but with expanded list
export const cities = indianCities;
