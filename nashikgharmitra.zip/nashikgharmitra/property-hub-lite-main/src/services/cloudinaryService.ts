/**
 * Cloudinary Image Upload Service
 * Handles secure image uploads with automatic compression and optimization
 * Images stored on Cloudinary CDN (free tier: 25 GB storage + monthly credits)
 */

const CLOUDINARY_CLOUD_NAME = import.meta.env.VITE_CLOUDINARY_CLOUD_NAME || '';
const CLOUDINARY_UPLOAD_PRESET = 'nashik_properties'; // Unsigned upload preset (optional)

interface CloudinaryUploadResponse {
  secure_url: string;
  public_id: string;
  width: number;
  height: number;
  bytes: number;
  format: string;
}

interface UploadResult {
  success: boolean;
  url?: string;
  publicId?: string;
  error?: string;
  size?: number;
}

/**
 * Validates image file before upload
 */
export const validateImage = (file: File): { valid: boolean; error?: string } => {
  const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
  const maxSize = 10 * 1024 * 1024; // 10MB before compression

  if (!validTypes.includes(file.type)) {
    return {
      valid: false,
      error: 'Only JPG, PNG, and WebP images are allowed',
    };
  }

  if (file.size > maxSize) {
    return {
      valid: false,
      error: 'Image size must be less than 10MB',
    };
  }

  return { valid: true };
};

/**
 * Compresses image client-side before upload
 * Target: 150-250 KB per image
 */
export const compressImage = async (file: File): Promise<File> => {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = document.createElement('img');

    img.onload = () => {
      // Resize to max dimensions
      const maxWidth = 1200;
      const maxHeight = 900;
      let { width, height } = img;

      if (width > maxWidth || height > maxHeight) {
        const ratio = Math.min(maxWidth / width, maxHeight / height);
        width *= ratio;
        height *= ratio;
      }

      canvas.width = width;
      canvas.height = height;
      ctx?.drawImage(img, 0, 0, width, height);

      // Convert to JPEG with optimized quality
      canvas.toBlob(
        (blob) => {
          if (blob) {
            resolve(new File([blob], file.name, { type: 'image/jpeg' }));
          } else {
            resolve(file);
          }
        },
        'image/jpeg',
        0.7 // 70% quality for target 150-250KB
      );
    };

    img.src = URL.createObjectURL(file);
  });
};

/**
 * Upload image to Cloudinary using API (requires backend signature for security)
 * For free tier, uses environment variables with signature authentication
 */
export const uploadToCloudinary = async (file: File, folder: string = 'nashik_properties'): Promise<UploadResult> => {
  try {
    if (!CLOUDINARY_CLOUD_NAME) {
      return {
        success: false,
        error: 'Cloudinary configuration missing',
      };
    }

    // Compress image first
    const compressedFile = await compressImage(file);

    // Create FormData for upload
    const formData = new FormData();
    formData.append('file', compressedFile);
    formData.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);
    formData.append('folder', folder);
    formData.append('resource_type', 'auto');
    // Cloudinary transformations
    formData.append('eager', 'w_400,h_300,c_fill|w_200,h_150,c_fill');
    formData.append('eager_async', 'true');

    // Upload to Cloudinary
    const response = await fetch(
      `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload`,
      {
        method: 'POST',
        body: formData,
      }
    );

    if (!response.ok) {
      const error = await response.json();
      return {
        success: false,
        error: error.error?.message || 'Failed to upload image',
      };
    }

    const data: CloudinaryUploadResponse = await response.json();

    return {
      success: true,
      url: data.secure_url,
      publicId: data.public_id,
      size: data.bytes,
    };
  } catch (error) {
    console.error('Upload error:', error);
    return {
      success: false,
      error: 'Network error during upload',
    };
  }
};

/**
 * Generate optimized image URL with transformations
 * Automatic responsive sizing for different devices
 */
export const getOptimizedImageUrl = (publicId: string, width?: number, height?: number): string => {
  if (!CLOUDINARY_CLOUD_NAME) return '';

  const baseUrl = `https://res.cloudinary.com/${CLOUDINARY_CLOUD_NAME}/image/upload`;
  const transformations: string[] = [];

  if (width || height) {
    const w = width ? `w_${width}` : '';
    const h = height ? `h_${height}` : '';
    transformations.push([w, h, 'c_fill'].filter(Boolean).join(','));
  } else {
    // Default transformation: responsive with quality optimization
    transformations.push('w_600,h_400,c_fill,q_auto,f_auto');
  }

  const transform = transformations.length > 0 ? `/${transformations.join('/')}` : '';
  return `${baseUrl}${transform}/${publicId}`;
};

/**
 * Get thumbnail URL for quick loading
 */
export const getThumbnailUrl = (publicId: string): string => {
  return getOptimizedImageUrl(publicId, 200, 150);
};

/**
 * Batch upload multiple images
 */
export const batchUploadImages = async (files: File[], folder: string = 'nashik_properties'): Promise<UploadResult[]> => {
  const results = await Promise.all(
    files.map((file) => uploadToCloudinary(file, folder))
  );
  return results;
};

/**
 * Delete image from Cloudinary (requires admin API key - backend only)
 */
export const deleteImage = async (publicId: string): Promise<boolean> => {
  try {
    // This should be called from backend to avoid exposing API secret
    const response = await fetch('/api/cloudinary/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ publicId }),
    });

    return response.ok;
  } catch (error) {
    console.error('Delete error:', error);
    return false;
  }
};
