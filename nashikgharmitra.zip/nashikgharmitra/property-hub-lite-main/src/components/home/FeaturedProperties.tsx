import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import PropertyCard, { PropertyCardData } from '@/components/property/PropertyCard';
import { Button } from '@/components/ui/button';
import { useFeaturedProperties, Property } from '@/hooks/useProperties';
import { Skeleton } from '@/components/ui/skeleton';

const FeaturedProperties = () => {
  const { data: properties, isLoading } = useFeaturedProperties(4);

  const mapToPropertyCard = (property: Property): PropertyCardData => ({
    id: property.id,
    title: property.title,
    price: property.price,
    type: property.listing_type as 'sale' | 'rent',
    propertyType: property.property_type,
    bedrooms: property.bedrooms || 0,
    bathrooms: property.bathrooms || 0,
    area: property.area || 0,
    location: property.address,
    city: property.city,
    images: property.images || undefined,
    featured: property.is_featured || false,
    boosted: property.is_boosted || false,
  });

  if (isLoading) {
    return (
      <section className="py-16 md:py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
            <div>
              <span className="text-accent font-semibold text-sm uppercase tracking-wider">Handpicked for you</span>
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mt-2">
                Featured Properties
              </h2>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="h-48 w-full rounded-xl" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (!properties || properties.length === 0) {
    return null;
  }

  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
          <div>
            <span className="text-accent font-semibold text-sm uppercase tracking-wider">Handpicked for you</span>
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mt-2">
              Featured Properties
            </h2>
          </div>
          <Link to="/properties?featured=true">
            <Button variant="outline" className="group">
              View All Properties
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>

        {/* Property Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {properties.map((property, index) => (
            <div
              key={property.id}
              className="animate-fade-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <PropertyCard property={mapToPropertyCard(property)} featured />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedProperties;