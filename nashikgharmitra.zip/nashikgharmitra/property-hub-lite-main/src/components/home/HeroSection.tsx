import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, MapPin, Home, Building2, LandPlot } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cities } from '@/data/mockProperties';

const HeroSection = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'buy' | 'rent'>('buy');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCity, setSelectedCity] = useState('');
  const [propertyType, setPropertyType] = useState('');

  const handleSearch = () => {
    const params = new URLSearchParams();
    params.set('type', activeTab === 'buy' ? 'sale' : 'rent');
    if (searchQuery) params.set('q', searchQuery);
    if (selectedCity) params.set('city', selectedCity);
    if (propertyType) params.set('propertyType', propertyType);
    navigate(`/properties?${params.toString()}`);
  };

  const propertyTypes = [
    { id: 'apartment', label: 'Apartment', icon: Building2 },
    { id: 'house', label: 'House', icon: Home },
    { id: 'villa', label: 'Villa', icon: Home },
    { id: 'plot', label: 'Plot', icon: LandPlot },
  ];

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden pt-20" style={{ backgroundColor: '#0A3D62' }}>
      {/* Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0A3D62] via-[#1a5a8f] to-[#0A3D62]" />
      
      {/* Animated Orbs */}
      <div className="absolute top-20 right-10 w-72 h-72 rounded-full blur-3xl animate-pulse" style={{ background: '#F77F00 / 0.1' }} />
      <div className="absolute bottom-0 left-20 w-96 h-96 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s', background: '#F77F00 / 0.05' }} />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="max-w-5xl mx-auto text-center">
          {/* Headline */}
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-serif font-bold text-white mb-6 animate-fade-up leading-tight">
            Find Your Dream
            <span className="block drop-shadow-lg" style={{ color: '#F77F00' }}>Property Today</span>
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-12 max-w-3xl mx-auto animate-fade-up leading-relaxed" style={{ animationDelay: '0.1s' }}>
            Discover verified properties in Nashik. Buy, rent, or sell with confidence on NashikGharMitra.
          </p>

          {/* Search Box */}
          <div className="animate-fade-up max-w-4xl mx-auto rounded-2xl p-6 md:p-8 shadow-2xl" style={{ animationDelay: '0.2s', backgroundColor: '#FFFFFF', border: '1px solid #E6F0FA' }}>
            {/* Tabs */}
            <div className="flex gap-3 mb-8">
              {(['buy', 'rent'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className="flex-1 py-3 px-6 rounded-xl font-semibold text-sm transition-all duration-300 scale-100"
                  style={{
                    backgroundColor: activeTab === tab ? '#0A3D62' : '#F5F6FA',
                    color: activeTab === tab ? '#FFFFFF' : '#1F2933',
                    boxShadow: activeTab === tab ? '0 4px 12px #0A3D62/20' : 'none',
                    transform: activeTab === tab ? 'scale(1.05)' : 'scale(1)',
                    border: activeTab === tab ? 'none' : '1px solid #E6F0FA'
                  }}
                >
                  {tab === 'buy' ? '🏠 Buy' : '🔑 Rent'}
                </button>
              ))}
            </div>

            {/* Property Type Selection */}
            <div className="flex flex-wrap gap-3 mb-8 justify-center">
              {propertyTypes.map((type) => (
                <button
                  key={type.id}
                  onClick={() => setPropertyType(propertyType === type.id ? '' : type.id)}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-300"
                  style={{
                    backgroundColor: propertyType === type.id ? '#0A3D62' : '#F5F6FA',
                    color: propertyType === type.id ? '#FFFFFF' : '#1F2933',
                    boxShadow: propertyType === type.id ? '0 4px 12px #0A3D62/20' : 'none',
                    transform: propertyType === type.id ? 'scale(1.05)' : 'scale(1)',
                    border: propertyType === type.id ? 'none' : '1px solid #E6F0FA'
                  }}
                >
                  <type.icon className="w-4 h-4" />
                  {type.label}
                </button>
              ))}
            </div>

            {/* Search Fields */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              {/* City Dropdown */}
              <div className="md:col-span-3 relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: '#0A3D62' }} />
                <select
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                  className="w-full pl-12 pr-4 py-3.5 rounded-xl appearance-none cursor-pointer transition-all"
                  style={{ backgroundColor: '#F5F6FA', border: '1px solid #E6F0FA', color: '#1F2933' }}
                  onFocus={(e) => e.currentTarget.style.boxShadow = '0 0 0 3px #E6F0FA'}
                  onBlur={(e) => e.currentTarget.style.boxShadow = 'none'}
                >
                  <option value="">All Locations</option>
                  {cities.map((city) => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </select>
              </div>

              {/* Search Input */}
              <div className="md:col-span-7 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: '#0A3D62' }} />
                <input
                  type="text"
                  placeholder="Search by locality, project, or keyword..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="w-full pl-12 pr-4 py-3.5 rounded-xl transition-all"
                  style={{ backgroundColor: '#F5F6FA', border: '1px solid #E6F0FA', color: '#1F2933' }}
                  onFocus={(e) => e.currentTarget.style.boxShadow = '0 0 0 3px #E6F0FA'}
                  onBlur={(e) => e.currentTarget.style.boxShadow = 'none'}
                />
              </div>

              {/* Search Button */}
              <div className="md:col-span-2">
                <Button onClick={handleSearch} className="w-full h-full py-3.5 rounded-xl font-semibold shadow-lg" size="lg" style={{ backgroundColor: '#F77F00', color: '#FFFFFF' }}>
                  <Search className="w-5 h-5 md:mr-2" />
                  <span className="hidden md:inline">Search</span>
                </Button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default HeroSection;
