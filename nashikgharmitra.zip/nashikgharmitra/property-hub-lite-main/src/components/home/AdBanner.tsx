import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useIsAdmin } from '@/hooks/useAdmin';
import AdInquiryModal from '@/components/AdInquiryModal';
import { Plus } from 'lucide-react';

interface AdBannerProps {
  variant?: 'horizontal' | 'square' | 'vertical';
  placement?: string;
  className?: string;
}

const AdBanner = ({ variant = 'horizontal', placement = 'homepage', className = '' }: AdBannerProps) => {
  const [showInquiry, setShowInquiry] = useState(false);
  const navigate = useNavigate();
  const { data: isAdmin } = useIsAdmin();

  // Fetch active ad for this placement
  const { data: ad } = useQuery({
    queryKey: ['ad', placement],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('ads')
        .select('*')
        .eq('placement', placement)
        .eq('is_active', true)
        .limit(1)
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
  });

  const dimensions = {
    horizontal: 'h-24 md:h-32',
    square: 'aspect-square',
    vertical: 'h-64 md:h-96',
  };

  // If admin, show "Create Ad" option when no ad exists
  if (isAdmin && !ad) {
    return (
      <div
        onClick={() => navigate('/admin')}
        className={`relative bg-gradient-to-br from-primary/10 to-primary/5 rounded-xl overflow-hidden border-2 border-dashed border-primary/30 flex items-center justify-center cursor-pointer hover:border-primary/50 hover:bg-primary/10 transition-colors ${dimensions[variant]} ${className}`}
      >
        <div className="text-center p-4">
          <Plus className="w-8 h-8 mx-auto text-primary mb-2" />
          <span className="text-sm text-primary font-medium">Create Ad</span>
          <p className="text-xs text-muted-foreground mt-1">Click to manage ads</p>
        </div>
      </div>
    );
  }

  // If there's an active ad, display it
  if (ad) {
    const handleClick = () => {
      if (ad.link_url) {
        window.open(ad.link_url, '_blank');
      }
    };

    return (
      <div
        onClick={handleClick}
        className={`relative rounded-xl overflow-hidden cursor-pointer ${dimensions[variant]} ${className}`}
      >
        {ad.image_url ? (
          <img src={ad.image_url} alt={ad.title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center">
            <span className="text-primary-foreground font-semibold text-lg">{ad.title}</span>
          </div>
        )}
        <div className="absolute top-2 right-2">
          <span className="text-[10px] bg-background/80 text-muted-foreground px-1.5 py-0.5 rounded uppercase tracking-wider">
            Ad
          </span>
        </div>
      </div>
    );
  }

  // Default: show inquiry option for non-admins
  return (
    <>
      <div
        onClick={() => setShowInquiry(true)}
        className={`relative bg-gradient-to-br from-muted to-muted/50 rounded-xl overflow-hidden border border-dashed border-border flex items-center justify-center cursor-pointer hover:border-primary/50 hover:bg-muted/80 transition-colors ${dimensions[variant]} ${className}`}
      >
        <div className="text-center p-4">
          <span className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Advertisement</span>
          <p className="text-sm text-muted-foreground mt-1">Your Ad Here</p>
          <p className="text-xs text-primary mt-2 font-medium">Click to Inquire</p>
        </div>
      </div>
      
      <AdInquiryModal open={showInquiry} onClose={() => setShowInquiry(false)} />
    </>
  );
};

export default AdBanner;