import { Link } from 'react-router-dom';
import { ArrowRight, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';

const CTASection = () => {
  return (
    <section className="py-20 md:py-28" style={{ backgroundColor: '#F5F6FA' }}>
      <div className="container mx-auto px-4">
        <div className="relative rounded-3xl overflow-hidden shadow-2xl" style={{ background: 'linear-gradient(135deg, #0A3D62 0%, #1a5a8f 100%)' }}>
          {/* Decorative Elements */}
          <div className="absolute top-0 right-0 w-80 h-80 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" style={{ background: '#FFFFFF / 0.15' }} />
          <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full translate-y-1/2 -translate-x-1/2 blur-3xl" style={{ background: '#F77F00 / 0.1' }} />

          <div className="relative z-10 grid md:grid-cols-2 gap-8 p-8 md:p-12 lg:p-16">
            {/* Post Property */}
            <div className="text-center md:text-left flex flex-col justify-center">
              <h3 className="text-3xl md:text-4xl font-serif font-bold text-white mb-4">
                Have a Property to Sell?
              </h3>
              <p className="mb-8 text-lg" style={{ color: 'rgba(255, 255, 255, 0.9)' }}>
                List your property for free and connect with serious buyers across Nashik.
              </p>
              <Link to="/post-property" className="inline-flex justify-center md:justify-start">
                <Button className="font-bold py-3 px-8 rounded-xl text-lg shadow-lg" style={{ backgroundColor: '#F77F00', color: '#FFFFFF' }}>
                  <Plus className="w-5 h-5 mr-2" />
                  Post Free Ad
                </Button>
              </Link>
            </div>

            {/* Looking for Property */}
            <div className="text-center md:text-left flex flex-col justify-center md:border-l md:pl-8" style={{ borderColor: 'rgba(255, 255, 255, 0.3)' }}>
              <h3 className="text-3xl md:text-4xl font-serif font-bold text-white mb-4">
                Looking to Buy or Rent?
              </h3>
              <p className="mb-8 text-lg" style={{ color: 'rgba(255, 255, 255, 0.9)' }}>
                Browse thousands of verified properties and find your perfect match instantly.
              </p>
              <Link to="/properties" className="inline-flex justify-center md:justify-start">
                <Button className="font-bold py-3 px-8 rounded-xl text-lg" style={{ backgroundColor: 'rgba(255, 255, 255, 0.15)', border: '2px solid #FFFFFF', color: '#FFFFFF', backdropFilter: 'blur(10px)' }}>
                  Explore Properties
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
