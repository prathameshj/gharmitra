import { Link } from 'react-router-dom';
import { Building2, Home, Castle, LandPlot, Store, Briefcase, ShoppingCart } from 'lucide-react';

const categories = [
  { id: 'apartment', label: 'Apartments', icon: Building2, count: 2450, color: 'bg-primary/10 text-primary' },
  { id: 'house', label: 'Houses', icon: Home, count: 1280, color: 'bg-success/10 text-success' },
  { id: 'villa', label: 'Villas', icon: Castle, count: 560, color: 'bg-accent/10 text-accent' },
  { id: 'plot', label: 'Plots & Land', icon: LandPlot, count: 890, color: 'bg-warning/10 text-warning' },
  { id: 'commercial', label: 'Commercial', icon: Store, count: 340, color: 'bg-destructive/10 text-destructive' },
  { id: 'office', label: 'Office Space', icon: Briefcase, count: 720, color: 'bg-primary/10 text-primary' },
];

const PropertyCategories = () => {
  return (
    <section className="py-20 md:py-28" style={{ backgroundColor: '#F5F6FA' }}>
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="font-bold text-sm uppercase tracking-widest" style={{ color: '#0A3D62' }}>PROPERTY TYPES</span>
          <h2 className="text-4xl md:text-5xl font-serif font-bold mt-3" style={{ color: '#1F2933' }}>
            Browse Properties by Category
          </h2>
          <p className="text-lg mt-4" style={{ color: '#6B7280' }}>Find exactly what you're looking for</p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-5">
          {categories.map((category, index) => (
            <Link
              key={category.id}
              to={`/properties?propertyType=${category.id}`}
              className="group rounded-2xl p-6 text-center border-2 shadow-sm transition-all duration-300 animate-fade-up"
              style={{ animationDelay: `${index * 0.05}s`, backgroundColor: '#FFFFFF', borderColor: '#E6F0FA' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow = '0 12px 40px rgba(10, 61, 98, 0.12)';
                e.currentTarget.style.borderColor = '#0A3D62';
                e.currentTarget.style.backgroundColor = '#E6F0FA';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow = '0 1px 2px rgba(10, 61, 98, 0.05)';
                e.currentTarget.style.borderColor = '#E6F0FA';
                e.currentTarget.style.backgroundColor = '#FFFFFF';
              }}
            >
              <div className={`w-16 h-16 rounded-2xl ${category.color} flex items-center justify-center mx-auto mb-4 transition-transform duration-300`} style={{ transform: 'scale(1)' }} onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.25)'} onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}>
                <category.icon className="w-8 h-8" />
              </div>
              <h3 className="font-bold mb-2 text-lg" style={{ color: '#1F2933' }}>{category.label}</h3>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PropertyCategories;
