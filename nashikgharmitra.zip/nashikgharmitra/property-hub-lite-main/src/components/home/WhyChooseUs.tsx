import { Shield, Clock, Users, Award, HeadphonesIcon, TrendingUp } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Verified Listings',
    description: 'All properties are verified to ensure authenticity and protect your interests.',
  },
  {
    icon: Clock,
    title: 'Save Time',
    description: 'Advanced filters and smart search help you find your ideal property faster.',
  },
  {
    icon: Users,
    title: 'Direct Contact',
    description: 'Connect directly with property owners without any middlemen.',
  },
  {
    icon: Award,
    title: 'Trusted Platform',
    description: 'Serving thousands of happy customers with reliable property services.',
  },
  {
    icon: HeadphonesIcon,
    title: '24/7 Support',
    description: 'Our dedicated support team is always ready to assist you.',
  },
  {
    icon: TrendingUp,
    title: 'Market Insights',
    description: 'Get real-time market trends and property valuation insights.',
  },
];

const WhyChooseUs = () => {
  return (
    <section className="py-20 md:py-28 text-white relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #0A3D62 0%, #1a5a8f 100%)' }}>
      {/* Decorative Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" style={{ background: '#F77F00 / 0.08' }} />
      <div className="absolute bottom-0 left-0 w-72 h-72 rounded-full translate-y-1/2 -translate-x-1/2 blur-3xl" style={{ background: '#FFFFFF / 0.05' }} />

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="font-bold text-sm uppercase tracking-widest" style={{ color: '#F77F00' }}>WHY CHOOSE US</span>
          <h2 className="text-4xl md:text-5xl font-serif font-bold mt-3 leading-tight text-white">
            India's Most Trusted Property Portal
          </h2>
          <p className="text-lg mt-4" style={{ color: '#FFFFFF', opacity: 0.85 }}>Everything you need for your real estate journey</p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="rounded-2xl p-8 border transition-all duration-300 animate-fade-up"
              style={{ 
                animationDelay: `${index * 0.1}s`,
                backgroundColor: 'rgba(255, 255, 255, 0.08)',
                borderColor: 'rgba(255, 255, 255, 0.2)',
                backdropFilter: 'blur(10px)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.4)';
                e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.12)';
                e.currentTarget.style.transform = 'scale(1.05)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.2)';
                e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.08)';
                e.currentTarget.style.transform = 'scale(1)';
              }}
            >
              <div className="w-14 h-14 rounded-xl flex items-center justify-center mb-5" style={{ backgroundColor: 'rgba(247, 127, 0, 0.2)' }}>
                <feature.icon className="w-7 h-7" style={{ color: '#F77F00' }} />
              </div>
              <h3 className="text-xl font-bold mb-3 text-white">{feature.title}</h3>
              <p className="text-sm leading-relaxed" style={{ color: 'rgba(255, 255, 255, 0.75)' }}>
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;
