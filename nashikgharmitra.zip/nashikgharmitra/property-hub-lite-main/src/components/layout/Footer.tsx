import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin, MessageCircle } from 'lucide-react';

const PHONE_NUMBER = '+917218174338';
const WHATSAPP_MESSAGE = 'Hi, I am interested in your property services.';

const Footer = () => {
  const whatsappUrl = `https://wa.me/${PHONE_NUMBER.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}`;
  
  return (
    <footer className="bg-foreground text-background">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="text-xl font-serif font-bold hover:opacity-90 transition-opacity inline-block">
              NashikGharMitra
            </Link>
            <p className="text-background/70 text-sm leading-relaxed">
              Your trusted partner in finding the perfect property in Nashik. We connect buyers, sellers, and renters locally.
            </p>
            <div className="flex gap-3">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-background/10 flex items-center justify-center hover:bg-[#25D366] transition-colors"
                aria-label="WhatsApp"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
              {[Facebook, Instagram, Linkedin].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-9 h-9 rounded-full bg-background/10 flex items-center justify-center hover:bg-primary transition-colors"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/properties?type=sale" className="text-background/70 hover:text-background transition-colors">
                  Buy Property
                </Link>
              </li>
              <li>
                <Link to="/properties?type=rent" className="text-background/70 hover:text-background transition-colors">
                  Rent Property
                </Link>
              </li>
              <li>
                <Link to="/post-property" className="text-background/70 hover:text-background transition-colors">
                  Post Property
                </Link>
              </li>
            </ul>
          </div>

          {/* Property Types */}
          <div>
            <h4 className="font-semibold mb-4">Property Types</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/properties?propertyType=apartment" className="text-background/70 hover:text-background transition-colors">
                  Apartments
                </Link>
              </li>
              <li>
                <Link to="/properties?propertyType=house" className="text-background/70 hover:text-background transition-colors">
                  Independent Houses
                </Link>
              </li>
              <li>
                <Link to="/properties?propertyType=villa" className="text-background/70 hover:text-background transition-colors">
                  Villas
                </Link>
              </li>
              <li>
                <Link to="/properties?propertyType=plot" className="text-background/70 hover:text-background transition-colors">
                  Plots & Land
                </Link>
              </li>
              <li>
                <Link to="/properties?propertyType=shop" className="text-background/70 hover:text-background transition-colors">
                  Shops
                </Link>
              </li>
              <li>
                <Link to="/properties?propertyType=commercial" className="text-background/70 hover:text-background transition-colors">
                  Commercial Space
                </Link>
              </li>
              <li>
                <Link to="/properties?propertyType=office" className="text-background/70 hover:text-background transition-colors">
                  Office Space
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold mb-4">Contact Us</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 mt-0.5 text-accent" />
                <span className="text-background/70">Plot no. 57, Konark Nagar, Adgaon, Nashik 422003</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-accent" />
                <a href="tel:+917218174338" className="text-background/70 hover:text-background transition-colors">
                  +91 7218174338
                </a>
              </li>
              <li className="flex items-center gap-3">
                <MessageCircle className="w-4 h-4 text-accent" />
                <a 
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-background/70 hover:text-background transition-colors"
                >
                  WhatsApp Us
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-accent" />
                <a href="mailto:nashikgharmitra@gmail.com" className="text-background/70 hover:text-background transition-colors">
                  nashikgharmitra@gmail.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-background/10 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-background/50">
            © {new Date().getFullYear()} NashikGharMitra. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm text-background/50">
            <Link to="/privacy" className="hover:text-background transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-background transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
