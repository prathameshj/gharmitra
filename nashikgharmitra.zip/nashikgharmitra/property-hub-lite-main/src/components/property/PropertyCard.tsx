import { Link } from 'react-router-dom';
import { Heart, MapPin, Bed, Bath, Maximize, CheckCircle, Rocket } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export interface PropertyCardData {
  id: string;
  title: string;
  type: 'sale' | 'rent';
  propertyType: string;
  price: number;
  area: number;
  bedrooms: number;
  bathrooms: number;
  location: string;
  city: string;
  image?: string;
  images?: string[];
  featured?: boolean;
  boosted?: boolean;
  verified?: boolean;
}

interface PropertyCardProps {
  property: PropertyCardData;
  featured?: boolean;
}

const formatPrice = (price: number, type: 'sale' | 'rent') => {
  if (type === 'rent') {
    return `₹${price.toLocaleString('en-IN')}/mo`;
  }
  if (price >= 10000000) {
    return `₹${(price / 10000000).toFixed(2)} Cr`;
  }
  if (price >= 100000) {
    return `₹${(price / 100000).toFixed(2)} Lac`;
  }
  return `₹${price.toLocaleString('en-IN')}`;
};

const PropertyCard = ({ property, featured = false }: PropertyCardProps) => {
  const isBoosted = property.boosted || property.featured;
  const displayImage = property.image || (property.images && property.images.length > 0 ? property.images[0] : '/placeholder.svg');

  return (
    <Link
      to={`/property/${property.id}`}
      className={`group block bg-card rounded-xl overflow-hidden border hover-lift transition-all duration-300 ${
        isBoosted 
          ? 'border-accent shadow-lg ring-2 ring-accent/30 relative' 
          : 'border-border shadow-sm'
      } ${featured ? 'shadow-lg' : ''}`}
    >
      {/* Boosted Glow Effect */}
      {isBoosted && (
        <div className="absolute inset-0 bg-gradient-to-br from-accent/5 to-transparent pointer-events-none z-0" />
      )}

      {/* Image */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={displayImage}
          alt={property.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          onError={(e) => {
            (e.target as HTMLImageElement).src = '/placeholder.svg';
          }}
        />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex gap-2 flex-wrap">
          <Badge className={`${property.type === 'sale' ? 'bg-primary' : 'bg-success'} text-primary-foreground border-0`}>
            For {property.type === 'sale' ? 'Sale' : 'Rent'}
          </Badge>
          {isBoosted && (
            <Badge className="bg-accent text-accent-foreground border-0 flex items-center gap-1">
              <Rocket className="w-3 h-3" />
              Featured
            </Badge>
          )}
        </div>

        {/* Verified Badge */}
        {property.verified && (
          <div className="absolute top-3 right-3 bg-card/90 backdrop-blur-sm rounded-full p-1.5">
            <CheckCircle className="w-4 h-4 text-success" />
          </div>
        )}

        {/* Favorite Button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            // Toggle favorite logic
          }}
          className="absolute bottom-3 right-3 w-9 h-9 bg-card/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-card transition-colors"
        >
          <Heart className="w-4 h-4 text-foreground" />
        </button>
      </div>

      {/* Content */}
      <div className={`p-4 relative z-10 ${isBoosted ? 'bg-card' : ''}`}>
        {/* Price */}
        <div className="flex items-baseline justify-between mb-2">
          <span className={`text-xl font-bold ${isBoosted ? 'text-accent' : 'text-primary'}`}>
            {formatPrice(property.price, property.type)}
          </span>
          <span className="text-xs text-muted-foreground capitalize">
            {property.propertyType}
          </span>
        </div>

        {/* Title */}
        <h3 className={`font-semibold text-foreground mb-2 line-clamp-1 transition-colors ${
          isBoosted ? 'group-hover:text-accent' : 'group-hover:text-primary'
        }`}>
          {property.title}
        </h3>

        {/* Location */}
        <div className="flex items-center gap-1.5 text-muted-foreground text-sm mb-3">
          <MapPin className="w-4 h-4" />
          <span className="line-clamp-1">{property.location}, {property.city}</span>
        </div>

        {/* Features */}
        <div className="flex items-center gap-4 text-sm text-muted-foreground pt-3 border-t border-border">
          {property.bedrooms > 0 && (
            <div className="flex items-center gap-1.5">
              <Bed className="w-4 h-4" />
              <span>{property.bedrooms} Beds</span>
            </div>
          )}
          {property.bathrooms > 0 && (
            <div className="flex items-center gap-1.5">
              <Bath className="w-4 h-4" />
              <span>{property.bathrooms} Baths</span>
            </div>
          )}
          <div className="flex items-center gap-1.5">
            <Maximize className="w-4 h-4" />
            <span>{property.area} sqft</span>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default PropertyCard;