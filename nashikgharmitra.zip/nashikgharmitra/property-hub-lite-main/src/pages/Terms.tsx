import { Helmet } from 'react-helmet-async';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { ChevronRight } from 'lucide-react';

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Service | NashikGharMitra - Property Portal</title>
        <meta name="description" content="Terms of Service for NashikGharMitra. Read our complete terms and conditions for using our property listing platform." />
        <meta name="keywords" content="terms of service, terms and conditions, property portal, user agreement" />
        <meta property="og:title" content="Terms of Service | NashikGharMitra" />
        <meta property="og:description" content="Read the terms and conditions for using NashikGharMitra" />
        <meta name="canonical" content={`${window.location.origin}/terms`} />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        
        <main className="flex-1 py-12 md:py-20">
          <div className="container mx-auto px-4 max-w-4xl">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 mb-8 text-sm text-muted-foreground">
              <a href="/" className="hover:text-foreground transition-colors">Home</a>
              <ChevronRight className="w-4 h-4" />
              <span className="text-foreground">Terms of Service</span>
            </div>

            {/* Header */}
            <div className="mb-12">
              <h1 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-4">
                Terms of Service
              </h1>
              <p className="text-lg text-muted-foreground">
                Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
            </div>

            {/* Content */}
            <div className="prose prose-invert max-w-none space-y-8 text-muted-foreground leading-relaxed">
              
              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">1. Agreement to Terms</h2>
                <p>
                  By accessing and using the NashikGharMitra website and services, you accept and agree to be bound by and comply with these Terms of Service. If you do not agree to abide by the above, please do not use this service.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">2. Use License</h2>
                <p>
                  Permission is granted to temporarily download one copy of the materials (information or software) on NashikGharMitra's website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-2 mt-3">
                  <li>Modify or copy the materials</li>
                  <li>Use the materials for any commercial purpose or for any public display</li>
                  <li>Attempt to decompile or reverse engineer any software contained on the website</li>
                  <li>Remove any copyright or other proprietary notations from the materials</li>
                  <li>Transfer the materials to another person or "mirror" the materials on any other server</li>
                  <li>Violate any applicable laws or regulations</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">3. Disclaimer of Warranties</h2>
                <p>
                  The materials on NashikGharMitra's website are provided on an 'as is' basis. NashikGharMitra makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">4. Limitations of Liability</h2>
                <p>
                  In no event shall NashikGharMitra or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on NashikGharMitra's website, even if we or our authorized representative has been notified orally or in writing of the possibility of such damage.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">5. Accuracy of Materials</h2>
                <p>
                  The materials appearing on NashikGharMitra's website could include technical, typographical, or photographic errors. NashikGharMitra does not warrant that any of the materials on its website are accurate, complete, or current. NashikGharMitra may make changes to the materials contained on its website at any time without notice.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">6. User Accounts</h2>
                <div className="space-y-4">
                  <p>
                    When you create an account on NashikGharMitra, you agree to:
                  </p>
                  <ul className="list-disc list-inside space-y-2 ml-2">
                    <li>Provide accurate, complete, and current information</li>
                    <li>Maintain the confidentiality of your password</li>
                    <li>Accept responsibility for all activities under your account</li>
                    <li>Notify us immediately of any unauthorized use</li>
                    <li>Comply with all applicable laws and regulations</li>
                  </ul>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">7. Property Listings</h2>
                <p>
                  Users who post property listings agree to:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-2 mt-3">
                  <li>Provide accurate and truthful property information</li>
                  <li>Own or have authority to list the property</li>
                  <li>Not engage in fraudulent, deceptive, or illegal practices</li>
                  <li>Not post discriminatory, hateful, or offensive content</li>
                  <li>Maintain copyright and intellectual property rights</li>
                  <li>Indemnify NashikGharMitra for violations of these terms</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">8. Prohibited Activities</h2>
                <p>You agree not to use the website to:</p>
                <ul className="list-disc list-inside space-y-2 ml-2 mt-3">
                  <li>Engage in fraudulent or deceptive practices</li>
                  <li>Violate any laws or regulations</li>
                  <li>Infringe on intellectual property rights</li>
                  <li>Harass, abuse, or harm others</li>
                  <li>Post spam, malware, or harmful content</li>
                  <li>Attempt to gain unauthorized access</li>
                  <li>Impersonate another person or entity</li>
                  <li>Collect or track personal information without consent</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">9. Termination</h2>
                <p>
                  NashikGharMitra reserves the right to terminate or suspend your account and access to the website immediately, without prior notice or liability, for any reason whatsoever, including if you breach these Terms of Service.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">10. Links to Third-Party Websites</h2>
                <p>
                  NashikGharMitra has not reviewed all of the sites linked to its website and is not responsible for the contents of any such linked site. The inclusion of any link does not imply endorsement by NashikGharMitra of the site. Use of any such linked website is at the user's own risk.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">11. Modifications of Terms</h2>
                <p>
                  NashikGharMitra may revise these Terms of Service for its website at any time without notice. By using this website, you are agreeing to be bound by the then current version of these Terms of Service.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">12. Governing Law</h2>
                <p>
                  These Terms of Service are governed by and construed in accordance with the laws of India, and you irrevocably submit to the exclusive jurisdiction of the courts in that location.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">13. Contact Information</h2>
                <p>
                  If you have questions about these Terms of Service, please contact us:
                </p>
                <div className="bg-card p-6 rounded-lg border border-border mt-4">
                  <p className="font-semibold text-foreground mb-2">NashikGharMitra</p>
                  <p>Plot no. 57, Konark Nagar, Adgaon, Nashik 422003</p>
                  <p className="mt-2">
                    <a href="tel:+917218174338" className="text-primary hover:underline">+91 7218174338</a>
                  </p>
                  <p>
                    <a href="mailto:nashikgharmitra@gmail.com" className="text-primary hover:underline">nashikgharmitra@gmail.com</a>
                  </p>
                </div>
              </section>

            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default Terms;
