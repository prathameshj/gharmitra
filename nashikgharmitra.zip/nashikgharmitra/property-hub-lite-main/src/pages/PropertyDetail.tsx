import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { ArrowLeft, Heart, Share2, MapPin, Bed, Bath, Maximize, Calendar, CheckCircle, Phone, MessageCircle, Building2, User, Loader2 } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import AdBanner from '@/components/home/AdBanner';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useProperty } from '@/hooks/useProperties';

const PHONE_NUMBER = '+917218174338';

const formatPrice = (price: number, type: string) => {
  if (type === 'rent') {
    return `₹${price.toLocaleString('en-IN')}/month`;
  }
  if (price >= 10000000) {
    return `₹${(price / 10000000).toFixed(2)} Crore`;
  }
  if (price >= 100000) {
    return `₹${(price / 100000).toFixed(2)} Lakh`;
  }
  return `₹${price.toLocaleString('en-IN')}`;
};

const PropertyDetail = () => {
  const { id } = useParams();
  const { data: property, isLoading, error } = useProperty(id || '');

  const getWhatsAppUrl = () => {
    if (!property) return '#';
    const message = `Hi, I am interested in the property: ${property.title} (${formatPrice(property.price, property.listing_type)}) at ${property.address}, ${property.city}. Please share more details.`;
    return `https://wa.me/${PHONE_NUMBER.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(message)}`;
  };

  const getCallUrl = () => `tel:${PHONE_NUMBER}`;

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </main>
        <Footer />
      </div>
    );
  }

  if (error || !property) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-foreground mb-4">Property Not Found</h1>
            <Link to="/properties">
              <Button>Back to Properties</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const mainImage = property.images?.[0] || '/placeholder.svg';

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1">
        <Helmet>
          <title>{property.title} | Property in {property.city} | NashikGharMitra</title>
          <meta name="description" content={`Check out this ${property.bedrooms} BHK ${property.property_type} for ${property.listing_type} in ${property.address}, ${property.city}. Verified property listing on NashikGharMitra.`} />
          <meta property="og:title" content={`${property.title} - NashikGharMitra`} />
          <meta property="og:description" content={`Find property in Nashik. Verified listing: ${property.title} at ${property.address}.`} />
          <meta property="og:image" content={property.images?.[0] || 'https://nashikgharmitra.vercel.app/nashik-ghar-mitra-logo.png'} />
          <link rel="canonical" href={`https://nashikgharmitra.vercel.app/property/${property.id}`} />
        </Helmet>
        {/* Breadcrumb */}
        <div className="bg-card border-b border-border">
          <div className="container mx-auto px-4 py-4">
            <Link to="/properties" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Properties
            </Link>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Image Gallery */}
              <div className="space-y-4">
                <div className="relative aspect-video rounded-xl overflow-hidden">
                  <img
                    src={mainImage}
                    alt={property.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 left-4 flex gap-2">
                    <Badge className={`${property.listing_type === 'sale' ? 'bg-primary' : 'bg-success'} text-primary-foreground border-0`}>
                      For {property.listing_type === 'sale' ? 'Sale' : 'Rent'}
                    </Badge>
                    {property.is_boosted && (
                      <Badge className="bg-accent text-accent-foreground border-0">
                        Featured
                      </Badge>
                    )}
                  </div>
                  <div className="absolute top-4 right-4 flex gap-2">
                    <button className="w-10 h-10 bg-card/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-card transition-colors">
                      <Heart className="w-5 h-5" />
                    </button>
                    <button className="w-10 h-10 bg-card/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-card transition-colors">
                      <Share2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                
                {/* Additional Images */}
                {property.images && property.images.length > 1 && (
                  <div className="grid grid-cols-4 gap-2">
                    {property.images.slice(1, 5).map((img, idx) => (
                      <div key={idx} className="aspect-video rounded-lg overflow-hidden">
                        <img src={img} alt={`${property.title} ${idx + 2}`} className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Property Info */}
              <div className="bg-card rounded-xl border border-border p-6">
                <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                  <div>
                    <h1 className="text-2xl md:text-3xl font-serif font-bold text-foreground mb-2">
                      {property.title}
                    </h1>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      <span>{property.address}, {property.city}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl md:text-3xl font-bold text-primary">
                      {formatPrice(property.price, property.listing_type)}
                    </div>
                    {property.area && (
                      <div className="text-sm text-muted-foreground">
                        ₹{Math.round(property.price / property.area).toLocaleString('en-IN')}/sqft
                      </div>
                    )}
                  </div>
                </div>

                {/* Key Features */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-6 border-y border-border">
                  {property.bedrooms && property.bedrooms > 0 && (
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Bed className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-semibold text-foreground">{property.bedrooms}</div>
                        <div className="text-xs text-muted-foreground">Bedrooms</div>
                      </div>
                    </div>
                  )}
                  {property.bathrooms && property.bathrooms > 0 && (
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Bath className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-semibold text-foreground">{property.bathrooms}</div>
                        <div className="text-xs text-muted-foreground">Bathrooms</div>
                      </div>
                    </div>
                  )}
                  {property.area && (
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Maximize className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-semibold text-foreground">{property.area}</div>
                        <div className="text-xs text-muted-foreground">Sq. Ft.</div>
                      </div>
                    </div>
                  )}
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Building2 className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <div className="font-semibold text-foreground capitalize">{property.property_type}</div>
                      <div className="text-xs text-muted-foreground">Type</div>
                    </div>
                  </div>
                </div>

                {/* Description */}
                {property.description && (
                  <div className="py-6 border-b border-border">
                    <h2 className="text-lg font-semibold text-foreground mb-3">Description</h2>
                    <p className="text-muted-foreground leading-relaxed">{property.description}</p>
                  </div>
                )}

                {/* Amenities */}
                {property.amenities && property.amenities.length > 0 && (
                  <div className="py-6">
                    <h2 className="text-lg font-semibold text-foreground mb-4">Amenities</h2>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {property.amenities.map((amenity) => (
                        <div key={amenity} className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-success" />
                          <span className="text-sm text-foreground">{amenity}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Ad Banner */}
              <AdBanner variant="horizontal" />
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Contact Card */}
              <div className="bg-card rounded-xl border border-border p-6 sticky top-24">
                <h3 className="font-semibold text-foreground mb-4">Contact Owner</h3>
                
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <div className="font-semibold text-foreground">GharMitra</div>
                    <div className="text-sm text-muted-foreground">Property Consultant</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <a href={getCallUrl()}>
                    <Button className="w-full" size="lg">
                      <Phone className="w-4 h-4 mr-2" />
                      Call Now
                    </Button>
                  </a>
                  <a href={getWhatsAppUrl()} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" className="w-full bg-[#25D366] hover:bg-[#128C7E] text-white border-0 hover:text-white" size="lg">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      WhatsApp
                    </Button>
                  </a>
                </div>

                <div className="mt-6 pt-6 border-t border-border">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    <span>Posted on {new Date(property.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                  </div>
                </div>
              </div>

              {/* Sidebar Ad */}
              <AdBanner variant="vertical" />
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default PropertyDetail;
