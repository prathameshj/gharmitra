import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Trash2, Star, StarOff, Rocket, CheckCircle, Mail, Phone, Plus, Eye, EyeOff, Upload, X } from 'lucide-react';

const Admin = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showAdForm, setShowAdForm] = useState(false);
  const [adForm, setAdForm] = useState({ title: '', link_url: '', placement: 'homepage' });
  const [adImageFile, setAdImageFile] = useState<File | null>(null);
  const [uploadingAd, setUploadingAd] = useState(false);

  // Check if user is admin
  useEffect(() => {
    const checkAdmin = async () => {
      if (!user) {
        navigate('/login');
        return;
      }

      const { data } = await supabase.rpc('has_role', { _user_id: user.id, _role: 'admin' });
      if (!data) {
        toast.error('Access denied. Admin only.');
        navigate('/');
        return;
      }
      setIsAdmin(true);
      setLoading(false);
    };
    checkAdmin();
  }, [user, navigate]);

  // Fetch all properties
  const { data: properties } = useQuery({
    queryKey: ['admin-properties'],
    queryFn: async () => {
      const { data, error } = await supabase.from('properties').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: isAdmin,
  });

  // Fetch ad inquiries
  const { data: adInquiries } = useQuery({
    queryKey: ['admin-ad-inquiries'],
    queryFn: async () => {
      const { data, error } = await supabase.from('ad_inquiries').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: isAdmin,
  });

  // Fetch ads
  const { data: ads } = useQuery({
    queryKey: ['admin-ads'],
    queryFn: async () => {
      const { data, error } = await supabase.from('ads').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: isAdmin,
  });

  // Mutations
  const toggleFeatured = useMutation({
    mutationFn: async ({ id, featured }: { id: string; featured: boolean }) => {
      const { error } = await supabase.from('properties').update({ is_featured: featured }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-properties'] });
      toast.success('Property updated');
    },
  });

  const toggleBoosted = useMutation({
    mutationFn: async ({ id, boosted }: { id: string; boosted: boolean }) => {
      const { error } = await supabase.from('properties').update({ is_boosted: boosted }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-properties'] });
      toast.success('Property updated');
    },
  });

  const markSold = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('properties').update({ is_sold: true }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-properties'] });
      toast.success('Property marked as sold');
    },
  });

  const deleteProperty = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('properties').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-properties'] });
      toast.success('Property deleted');
    },
  });

  const toggleAdActive = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      const { error } = await supabase.from('ads').update({ is_active: active }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-ads'] });
      toast.success('Ad updated');
    },
  });

  const deleteAd = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('ads').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-ads'] });
      toast.success('Ad deleted');
    },
  });

  const deleteAdInquiry = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('ad_inquiries').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-ad-inquiries'] });
      toast.success('Inquiry discarded');
    },
    onError: (error) => {
      toast.error('Failed to discard: ' + (error instanceof Error ? error.message : 'Unknown error'));
    }
  });

  const handleCreateAd = async () => {
    if (!adForm.title) {
      toast.error('Please enter an ad title');
      return;
    }

    setUploadingAd(true);
    try {
      let imageUrl = '';
      
      if (adImageFile) {
        const fileExt = adImageFile.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
        
        const { error: uploadError } = await supabase.storage
          .from('property-images')
          .upload(`ads/${fileName}`, adImageFile);
        
        if (uploadError) throw uploadError;
        
        const { data: { publicUrl } } = supabase.storage
          .from('property-images')
          .getPublicUrl(`ads/${fileName}`);
        
        imageUrl = publicUrl;
      }

      const { error } = await supabase.from('ads').insert({
        title: adForm.title,
        link_url: adForm.link_url || null,
        placement: adForm.placement,
        image_url: imageUrl || null,
      });

      if (error) throw error;

      toast.success('Ad created successfully');
      queryClient.invalidateQueries({ queryKey: ['admin-ads'] });
      setShowAdForm(false);
      setAdForm({ title: '', link_url: '', placement: 'homepage' });
      setAdImageFile(null);
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to create ad';
      toast.error(errorMessage);
    } finally {
      setUploadingAd(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-serif font-bold text-foreground mb-8">Admin Panel</h1>

          <Tabs defaultValue="properties">
            <TabsList className="mb-6">
              <TabsTrigger value="properties">Properties ({properties?.length || 0})</TabsTrigger>
              <TabsTrigger value="ads-manage">Manage Ads ({ads?.length || 0})</TabsTrigger>
              <TabsTrigger value="ads">Ad Inquiries ({adInquiries?.length || 0})</TabsTrigger>
            </TabsList>

            <TabsContent value="properties">
              <div className="bg-card rounded-xl border border-border overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-4 font-medium">Property</th>
                        <th className="text-left p-4 font-medium">Price</th>
                        <th className="text-left p-4 font-medium">Status</th>
                        <th className="text-left p-4 font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {properties?.map((property) => (
                        <tr key={property.id} className="border-t border-border">
                          <td className="p-4">
                            <div className="flex items-center gap-3">
                              <div className="w-16 h-12 rounded-lg overflow-hidden bg-muted">
                                <img
                                  src={property.images?.[0] || '/placeholder.svg'}
                                  alt=""
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div>
                                <p className="font-medium text-foreground line-clamp-1">{property.title}</p>
                                <p className="text-sm text-muted-foreground">{property.city}</p>
                              </div>
                            </div>
                          </td>
                          <td className="p-4 text-foreground">₹{property.price.toLocaleString()}</td>
                          <td className="p-4">
                            <div className="flex gap-1 flex-wrap">
                              {property.is_sold && <Badge variant="destructive">Sold</Badge>}
                              {property.is_featured && <Badge className="bg-accent">Featured</Badge>}
                              {property.is_boosted && <Badge className="bg-primary">Boosted</Badge>}
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => toggleFeatured.mutate({ id: property.id, featured: !property.is_featured })}
                              >
                                {property.is_featured ? <StarOff className="w-4 h-4" /> : <Star className="w-4 h-4" />}
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => toggleBoosted.mutate({ id: property.id, boosted: !property.is_boosted })}
                              >
                                <Rocket className="w-4 h-4" />
                              </Button>
                              {!property.is_sold && (
                                <Button size="sm" variant="outline" onClick={() => markSold.mutate(property.id)}>
                                  <CheckCircle className="w-4 h-4" />
                                </Button>
                              )}
                              <Button size="sm" variant="destructive" onClick={() => deleteProperty.mutate(property.id)}>
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="ads-manage">
              <div className="mb-6">
                <Button onClick={() => setShowAdForm(!showAdForm)}>
                  {showAdForm ? <X className="w-4 h-4 mr-2" /> : <Plus className="w-4 h-4 mr-2" />}
                  {showAdForm ? 'Cancel' : 'Create New Ad'}
                </Button>
              </div>

              {showAdForm && (
                <div className="bg-card rounded-xl border border-border p-6 mb-6">
                  <h3 className="text-lg font-semibold mb-4">Create New Advertisement</h3>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <Label htmlFor="ad-title">Ad Title *</Label>
                      <Input
                        id="ad-title"
                        value={adForm.title}
                        onChange={(e) => setAdForm({ ...adForm, title: e.target.value })}
                        placeholder="Enter ad title"
                      />
                    </div>
                    <div>
                      <Label htmlFor="ad-link">Link URL (optional)</Label>
                      <Input
                        id="ad-link"
                        value={adForm.link_url}
                        onChange={(e) => setAdForm({ ...adForm, link_url: e.target.value })}
                        placeholder="https://example.com"
                      />
                    </div>
                    <div>
                      <Label htmlFor="ad-placement">Placement</Label>
                      <Select value={adForm.placement} onValueChange={(v) => setAdForm({ ...adForm, placement: v })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="homepage">Homepage (728 × 90 px)</SelectItem>
                          <SelectItem value="sidebar">Sidebar (300 × 250 px)</SelectItem>
                          <SelectItem value="properties">Properties Page (728 × 90 px)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="md:col-span-2">
                      <Label htmlFor="ad-image">Ad Image</Label>
                      <div className="mt-2 p-4 border-2 border-dashed border-border rounded-lg bg-muted/30">
                        <Input
                          id="ad-image"
                          type="file"
                          accept="image/*"
                          onChange={(e) => setAdImageFile(e.target.files?.[0] || null)}
                          className="mb-2"
                        />
                        <div className="text-sm text-muted-foreground space-y-1">
                          <p className="font-medium">Recommended dimensions:</p>
                          <ul className="list-disc list-inside ml-2">
                            <li><strong>Homepage:</strong> 728 × 90 pixels (Leaderboard)</li>
                            <li><strong>Sidebar:</strong> 300 × 250 pixels (Medium Rectangle)</li>
                            <li><strong>Properties Page:</strong> 728 × 90 pixels (Leaderboard)</li>
                          </ul>
                          <p className="text-xs mt-2">Supported formats: JPG, PNG, WebP (Max 5MB)</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <Button className="mt-4" onClick={handleCreateAd} disabled={uploadingAd}>
                    {uploadingAd ? (
                      <>
                        <Upload className="w-4 h-4 mr-2 animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4 mr-2" />
                        Create Ad
                      </>
                    )}
                  </Button>
                </div>
              )}

              <div className="grid gap-4">
                {ads?.map((ad) => (
                  <div key={ad.id} className="bg-card rounded-xl border border-border p-6 flex items-center gap-4">
                    {ad.image_url ? (
                      <div className="w-24 h-16 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                        <img src={ad.image_url} alt="" className="w-full h-full object-cover" />
                      </div>
                    ) : (
                      <div className="w-24 h-16 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                        <span className="text-xs text-muted-foreground">No image</span>
                      </div>
                    )}
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground">{ad.title}</h3>
                      <p className="text-sm text-muted-foreground">Placement: {ad.placement}</p>
                      {ad.link_url && <p className="text-sm text-primary truncate">{ad.link_url}</p>}
                    </div>
                    <Badge variant={ad.is_active ? 'default' : 'secondary'}>
                      {ad.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => toggleAdActive.mutate({ id: ad.id, active: !ad.is_active })}
                      >
                        {ad.is_active ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => deleteAd.mutate(ad.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
                {(!ads || ads.length === 0) && (
                  <p className="text-muted-foreground text-center py-8">No ads created yet. Create your first ad above.</p>
                )}
              </div>
            </TabsContent>

            <TabsContent value="ads">
              <div className="grid gap-4">
                {adInquiries?.map((inquiry) => (
                  <div key={inquiry.id} className="bg-card rounded-xl border border-border p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="font-semibold text-foreground">{inquiry.name}</h3>
                        <p className="text-sm text-muted-foreground">{inquiry.ad_type}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge>{inquiry.status}</Badge>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                          onClick={() => {
                            if (window.confirm('Are you sure you want to discard this inquiry?')) {
                              deleteAdInquiry.mutate(inquiry.id);
                            }
                          }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-foreground mb-4">{inquiry.message}</p>
                    <div className="flex gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1"><Mail className="w-4 h-4" />{inquiry.email}</span>
                      {inquiry.phone && <span className="flex items-center gap-1"><Phone className="w-4 h-4" />{inquiry.phone}</span>}
                    </div>
                  </div>
                ))}
                {(!adInquiries || adInquiries.length === 0) && (
                  <p className="text-muted-foreground text-center py-8">No ad inquiries yet.</p>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Admin;