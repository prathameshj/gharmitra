import { Helmet } from 'react-helmet-async';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { ChevronRight } from 'lucide-react';

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | NashikGharMitra - Property Portal</title>
        <meta name="description" content="Privacy Policy for NashikGharMitra - Learn how we protect your personal information and data. Read our complete privacy statement." />
        <meta name="keywords" content="privacy policy, data protection, personal information, property portal" />
        <meta property="og:title" content="Privacy Policy | NashikGharMitra" />
        <meta property="og:description" content="Learn how NashikGharMitra protects your personal information" />
        <meta name="canonical" content={`${window.location.origin}/privacy`} />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        
        <main className="flex-1 py-12 md:py-20">
          <div className="container mx-auto px-4 max-w-4xl">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 mb-8 text-sm text-muted-foreground">
              <a href="/" className="hover:text-foreground transition-colors">Home</a>
              <ChevronRight className="w-4 h-4" />
              <span className="text-foreground">Privacy Policy</span>
            </div>

            {/* Header */}
            <div className="mb-12">
              <h1 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-4">
                Privacy Policy
              </h1>
              <p className="text-lg text-muted-foreground">
                Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
            </div>

            {/* Content */}
            <div className="prose prose-invert max-w-none space-y-8 text-muted-foreground leading-relaxed">
              
              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">1. Introduction</h2>
                <p>
                  NashikGharMitra ("we," "our," or "us") operates the property listing portal at nashikgharmitra.com. We are committed to protecting your privacy and ensuring you have a positive experience on our website. This Privacy Policy outlines how we collect, use, disclose, and safeguard your information when you visit our platform.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">2. Information We Collect</h2>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">Personal Information You Provide</h3>
                    <ul className="list-disc list-inside space-y-2 ml-2">
                      <li>Name, email address, and phone number</li>
                      <li>Account credentials and password</li>
                      <li>Property listing details and descriptions</li>
                      <li>Payment and billing information</li>
                      <li>Profile information and preferences</li>
                      <li>Messages and communications with other users</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">Automatically Collected Information</h3>
                    <ul className="list-disc list-inside space-y-2 ml-2">
                      <li>Browser type and IP address</li>
                      <li>Pages visited and time spent on site</li>
                      <li>Device information and operating system</li>
                      <li>Cookies and tracking technology data</li>
                      <li>Geographic location (if permitted)</li>
                    </ul>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">3. How We Use Your Information</h2>
                <ul className="list-disc list-inside space-y-2 ml-2">
                  <li>To create and maintain your account</li>
                  <li>To process property listings and transactions</li>
                  <li>To communicate about your account and listings</li>
                  <li>To improve our website and services</li>
                  <li>To send marketing communications (with your consent)</li>
                  <li>To prevent fraud and ensure security</li>
                  <li>To comply with legal obligations</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">4. Data Security</h2>
                <p>
                  We implement industry-standard security measures including encryption, secure socket layer (SSL) technology, and secure password storage to protect your personal information. However, no method of transmission over the internet is 100% secure, and we cannot guarantee absolute security.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">5. Third-Party Disclosure</h2>
                <p>
                  We do not sell, trade, or rent your personal information to third parties. We may share information with:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-2 mt-3">
                  <li>Service providers who assist in operating our website</li>
                  <li>Law enforcement when required by law</li>
                  <li>Other users when you list properties publicly</li>
                  <li>Payment processors for secure transactions</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">6. Cookies and Tracking</h2>
                <p>
                  We use cookies to enhance your browsing experience, remember preferences, and analyze website usage. You can control cookie settings through your browser preferences. Disabling cookies may affect certain website functionality.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">7. Your Rights</h2>
                <p>You have the right to:</p>
                <ul className="list-disc list-inside space-y-2 ml-2 mt-3">
                  <li>Access your personal information</li>
                  <li>Request correction of inaccurate data</li>
                  <li>Request deletion of your account and data</li>
                  <li>Opt-out of marketing communications</li>
                  <li>Request information about our data practices</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">8. Children's Privacy</h2>
                <p>
                  Our website is not intended for children under 13 years of age. We do not knowingly collect personal information from children. If we become aware that a child has provided us with personal information, we will take steps to delete such information immediately.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">9. Changes to Privacy Policy</h2>
                <p>
                  We may update this Privacy Policy from time to time to reflect changes in our practices or applicable laws. We will notify you of significant changes by posting the updated policy on our website with a new "Last Updated" date.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">10. Contact Us</h2>
                <p>
                  If you have questions about this Privacy Policy or our privacy practices, please contact us:
                </p>
                <div className="bg-card p-6 rounded-lg border border-border mt-4">
                  <p className="font-semibold text-foreground mb-2">NashikGharMitra</p>
                  <p>Plot no. 57, Konark Nagar, Adgaon, Nashik 422003</p>
                  <p className="mt-2">
                    <a href="tel:+917218174338" className="text-primary hover:underline">+91 7218174338</a>
                  </p>
                  <p>
                    <a href="mailto:nashikgharmitra@gmail.com" className="text-primary hover:underline">nashikgharmitra@gmail.com</a>
                  </p>
                </div>
              </section>

            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default Privacy;
