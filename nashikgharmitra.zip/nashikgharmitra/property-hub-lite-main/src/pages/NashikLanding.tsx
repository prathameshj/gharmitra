import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { MapPin, Home, Building2, TrendingUp, ChevronRight } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { nashikAreas, createSlug, propertyTypes } from '@/data/nashikAreas';
import { useRecentProperties } from '@/hooks/useProperties';
import PropertyCard, { PropertyCardData } from '@/components/property/PropertyCard';
import type { Property } from '@/hooks/useProperties';

const NashikLanding = () => {
  const { data: recentProperties, isLoading } = useRecentProperties(6);

  const popularAreas = [
    { name: 'Gangapur Road', properties: 50 },
    { name: 'Cidco', properties: 45 },
    { name: 'Panchavati', properties: 40 },
    { name: 'Satpur', properties: 35 },
    { name: 'College Road', properties: 30 },
    { name: 'Nashik Road', properties: 28 },
    { name: 'Dwarka', properties: 25 },
    { name: 'Deolali', properties: 22 },
    { name: 'Ambad', properties: 20 },
    { name: 'Adgaon', properties: 18 },
    { name: 'Indiranagar', properties: 15 },
    { name: 'Trimbak Road', properties: 12 },
  ];

  const mapToPropertyCard = (property: Property): PropertyCardData => ({
    id: property.id,
    title: property.title,
    price: property.price,
    type: property.listing_type as 'sale' | 'rent',
    propertyType: property.property_type,
    bedrooms: property.bedrooms || 0,
    bathrooms: property.bathrooms || 0,
    area: property.area || 0,
    location: property.address,
    city: property.city,
    images: property.images || undefined,
    featured: property.is_featured || false,
    boosted: property.is_boosted || false,
  });

  return (
    <>
      <Helmet>
        <title>Property in Nashik - Buy, Sell, Rent Flats, Houses, Plots | NashikGharMitra</title>
        <meta
          name="description"
          content="Find property in Nashik - flats, apartments, houses, plots for sale and rent. Browse 500+ verified listings across Gangapur Road, Cidco, Panchavati, Satpur. Contact owners directly."
        />
        <meta property="og:title" content="Property in Nashik - Buy, Sell, Rent | NashikGharMitra" />
        <meta property="og:description" content="Nashik's trusted property platform. Find flats, houses, plots for sale and rent across all areas. Verified listings, direct owner contact." />
        <meta property="og:image" content="https://nashikgharmitra.vercel.app/nashik-ghar-mitra-logo.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Property in Nashik - Buy, Sell, Rent | NashikGharMitra" />
        <meta name="twitter:description" content="Nashik's trusted property platform. Find flats, houses, plots for sale and rent across all areas." />
        <meta name="twitter:image" content="https://nashikgharmitra.vercel.app/nashik-ghar-mitra-logo.png" />
        <link rel="canonical" href="https://nashikgharmitra.vercel.app/nashik" />

        {/* Local Business Schema */}
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'RealEstateAgent',
            name: 'NashikGharMitra - Nashik Property',
            description: "Nashik's trusted property platform for buying, selling, and renting homes.",
            url: 'https://nashikgharmitra.vercel.app/nashik',
            telephone: '+91-7218174338',
            email: 'nashikgharmitra@gmail.com',
            address: {
              '@type': 'PostalAddress',
              streetAddress: 'Plot no. 57, Konark Nagar, Adgaon',
              addressLocality: 'Nashik',
              addressRegion: 'Maharashtra',
              postalCode: '422003',
              addressCountry: 'IN',
            },
            areaServed: {
              '@type': 'City',
              name: 'Nashik',
            },
            priceRange: '₹₹',
          })}
        </script>
      </Helmet>

      <div className="min-h-screen flex flex-col bg-background">
        <Header />

        <main className="flex-1">
          {/* Hero Section */}
          <section className="bg-primary py-12 md:py-20">
            <div className="container mx-auto px-4 text-center">
              <h1 className="text-3xl md:text-5xl font-serif font-bold text-primary-foreground mb-4">
                Property in Nashik
              </h1>
              <p className="text-lg md:text-xl text-primary-foreground/80 mb-8 max-w-2xl mx-auto">
                Find your dream home in Nashik. Browse flats, houses, plots, and commercial spaces across all areas.
              </p>

              {/* Quick Search */}
              <div className="flex flex-wrap justify-center gap-4">
                <Button asChild size="lg" variant="secondary">
                  <Link to="/nashik/all/properties-for-sale">
                    <Home className="w-5 h-5 mr-2" />
                    Buy Property
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary">
                  <Link to="/nashik/all/properties-for-rent">
                    <Building2 className="w-5 h-5 mr-2" />
                    Rent Property
                  </Link>
                </Button>
              </div>
            </div>
          </section>

          {/* Popular Areas */}
          <section className="py-12 md:py-16">
            <div className="container mx-auto px-4">
              <h2 className="text-2xl md:text-3xl font-serif font-bold text-foreground mb-8 text-center">
                Popular Areas in Nashik
              </h2>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {popularAreas.map((area) => (
                  <Link
                    key={area.name}
                    to={`/nashik/${createSlug(area.name)}/properties-for-sale`}
                    className="bg-card border border-border rounded-xl p-4 hover:border-primary hover:shadow-lg transition-all group"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <MapPin className="w-4 h-4 text-primary" />
                      <span className="font-medium text-foreground group-hover:text-primary transition-colors">
                        {area.name}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">{area.properties}+ properties</p>
                  </Link>
                ))}
              </div>

              <div className="text-center mt-8">
                <Button asChild variant="outline">
                  <Link to="/properties">
                    View All Areas
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
              </div>
            </div>
          </section>

          {/* Property Types */}
          <section className="py-12 md:py-16 bg-muted/30">
            <div className="container mx-auto px-4">
              <h2 className="text-2xl md:text-3xl font-serif font-bold text-foreground mb-8 text-center">
                Browse by Property Type
              </h2>

              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {propertyTypes.map((type) => (
                  <Link
                    key={type.value}
                    to={`/nashik/all/${type.slug}-for-sale`}
                    className="bg-card border border-border rounded-xl p-6 text-center hover:border-primary hover:shadow-lg transition-all group"
                  >
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
                      <Building2 className="w-6 h-6 text-primary" />
                    </div>
                    <span className="font-medium text-foreground group-hover:text-primary transition-colors">
                      {type.label}s
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          </section>

          {/* Recent Properties */}
          {recentProperties && recentProperties.length > 0 && (
            <section className="py-12 md:py-16">
              <div className="container mx-auto px-4">
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-2xl md:text-3xl font-serif font-bold text-foreground">
                    Recent Properties in Nashik
                  </h2>
                  <Button asChild variant="ghost">
                    <Link to="/properties">
                      View All
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Link>
                  </Button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {recentProperties.map((property) => (
                    <PropertyCard key={property.id} property={mapToPropertyCard(property)} />
                  ))}
                </div>
              </div>
            </section>
          )}

          {/* All Areas List */}
          <section className="py-12 md:py-16 bg-muted/30">
            <div className="container mx-auto px-4">
              <h2 className="text-2xl md:text-3xl font-serif font-bold text-foreground mb-8 text-center">
                All Areas in Nashik District
              </h2>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
                {nashikAreas.map((area) => (
                  <Link
                    key={area}
                    to={`/nashik/${createSlug(area)}/properties-for-sale`}
                    className="py-2 px-3 text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {area}
                  </Link>
                ))}
              </div>
            </div>
          </section>

          {/* SEO Content */}
          <section className="py-12 md:py-16">
            <div className="container mx-auto px-4 max-w-4xl">
              <h2 className="text-2xl font-serif font-bold text-foreground mb-6">
                Find Property in Nashik with NashikGharMitra
              </h2>
              <div className="prose prose-lg text-muted-foreground">
                <p>
                  NashikGharMitra is Nashik's trusted property platform for finding your dream home. Whether you're looking
                  to buy a flat in Gangapur Road, rent an apartment in Cidco, or invest in a plot in Panchavati, we
                  have verified listings from property owners across all areas of Nashik District.
                </p>
                <p>
                  Browse through our extensive collection of residential and commercial properties including
                  apartments, houses, villas, plots, shops, and office spaces. Our platform connects you directly
                  with property owners, saving you brokerage fees and ensuring transparent dealings.
                </p>
                <h3 className="text-foreground">Why Choose GharMitra?</h3>
                <ul>
                  <li>Verified property listings with real photos</li>
                  <li>Direct contact with property owners</li>
                  <li>Zero brokerage fees</li>
                  <li>Comprehensive coverage of Nashik District</li>
                  <li>Easy listing process for property owners</li>
                </ul>
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default NashikLanding;
