import { useMemo, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Search, ChevronRight, Home, MapPin, Grid, List, SlidersHorizontal, X } from 'lucide-react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import PropertyCard, { PropertyCardData } from '@/components/property/PropertyCard';
import AdBanner from '@/components/home/AdBanner';
import { Button } from '@/components/ui/button';
import { useProperties, Property } from '@/hooks/useProperties';
import { Skeleton } from '@/components/ui/skeleton';
import { nashikAreas, parsePropertyRoute, propertyTypes, listingTypes, createSlug } from '@/data/nashikAreas';
import { useState } from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const NashikProperties = () => {
  const { area, filters } = useParams();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState('newest');

  // Parse route to get filters
  const routeFilters = useMemo(() => {
    const path = `/nashik/${area || ''}${filters ? `/${filters}` : ''}`;
    return parsePropertyRoute(path);
  }, [area, filters]);

  const { data: properties, isLoading } = useProperties({ excludeSold: true });

  const mapToPropertyCard = (property: Property): PropertyCardData => ({
    id: property.id,
    title: property.title,
    price: property.price,
    type: property.listing_type as 'sale' | 'rent',
    propertyType: property.property_type,
    bedrooms: property.bedrooms || 0,
    bathrooms: property.bathrooms || 0,
    area: property.area || 0,
    location: property.address,
    city: property.city,
    images: property.images || undefined,
    featured: property.is_featured || false,
    boosted: property.is_boosted || false,
  });

  // Filter properties based on route
  const filteredProperties = useMemo(() => {
    if (!properties) return [];

    let results = [...properties];

    // Filter by area
    if (routeFilters.area) {
      const areaLower = routeFilters.area.toLowerCase();
      results = results.filter(
        (p) =>
          p.address.toLowerCase().includes(areaLower) ||
          p.city.toLowerCase().includes(areaLower)
      );
    }

    // Filter by property type
    if (routeFilters.propertyType) {
      results = results.filter((p) => p.property_type === routeFilters.propertyType);
    }

    // Filter by listing type
    if (routeFilters.listingType) {
      results = results.filter((p) => p.listing_type === routeFilters.listingType);
    }

    // Filter by BHK
    if (routeFilters.bhk) {
      results = results.filter((p) => p.bedrooms === routeFilters.bhk);
    }

    // Sort
    switch (sortBy) {
      case 'price-low':
        results.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        results.sort((a, b) => b.price - a.price);
        break;
      case 'newest':
      default:
        results.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    }

    return results;
  }, [properties, routeFilters, sortBy]);

  // Generate SEO title and description
  const seoTitle = useMemo(() => {
    const parts = [];
    if (routeFilters.bhk) parts.push(`${routeFilters.bhk} BHK`);
    if (routeFilters.propertyType) {
      const type = propertyTypes.find((t) => t.value === routeFilters.propertyType);
      parts.push(type?.label || routeFilters.propertyType);
    }
    parts.push(routeFilters.listingType === 'rent' ? 'for Rent' : 'for Sale');
    if (routeFilters.area) parts.push(`in ${routeFilters.area}`);
    parts.push('Nashik');

    return `${parts.join(' ')} | NashikGharMitra`;
  }, [routeFilters]);

  const seoDescription = useMemo(() => {
    const count = filteredProperties.length;
    const typeLabel = routeFilters.propertyType
      ? propertyTypes.find((t) => t.value === routeFilters.propertyType)?.label.toLowerCase()
      : 'properties';
    const areaText = routeFilters.area ? ` in ${routeFilters.area}` : '';
    const bhkText = routeFilters.bhk ? `${routeFilters.bhk} BHK ` : '';
    const listingText = routeFilters.listingType === 'rent' ? 'for rent' : 'for sale';

    return `Find ${count}+ ${bhkText}${typeLabel} ${listingText}${areaText}, Nashik. Best deals on flats, apartments, houses, plots with verified listings. Contact owners directly on NashikGharMitra.`;
  }, [filteredProperties.length, routeFilters]);

  // Breadcrumb items
  const breadcrumbs = useMemo(() => {
    const items = [
      { label: 'Home', href: '/' },
      { label: 'Nashik', href: '/nashik' },
    ];

    if (routeFilters.area) {
      items.push({
        label: routeFilters.area,
        href: `/nashik/${createSlug(routeFilters.area)}`,
      });
    }

    return items;
  }, [routeFilters]);

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [area, filters]);

  return (
    <>
      <Helmet>
        <title>{seoTitle}</title>
        <meta name="description" content={seoDescription} />
        <meta property="og:title" content={seoTitle} />
        <meta property="og:description" content={seoDescription} />
        <meta property="og:type" content="website" />
        <link rel="canonical" href={`https://nashikgharmitra.vercel.app/nashik/${area || ''}${filters ? `/${filters}` : ''}`} />
        
        {/* Local Business Schema */}
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'RealEstateAgent',
            name: 'NashikGharMitra',
            description: 'Nashik\'s trusted property platform for buying, selling, and renting homes.',
            url: 'https://nashikgharmitra.vercel.app',
            telephone: '+91-7218174338',
            email: 'nashikgharmitra@gmail.com',
            address: {
              '@type': 'PostalAddress',
              streetAddress: 'Plot no. 57, Konark Nagar, Adgaon',
              addressLocality: 'Nashik',
              addressRegion: 'Maharashtra',
              postalCode: '422003',
              addressCountry: 'IN',
            },
            areaServed: {
              '@type': 'City',
              name: 'Nashik',
            },
            priceRange: '₹₹',
          })}
        </script>
        
        {/* BreadcrumbList Schema */}
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'BreadcrumbList',
            itemListElement: breadcrumbs.map((item, index) => ({
              '@type': 'ListItem',
              position: index + 1,
              name: item.label,
              item: `https://nashikgharmitra.vercel.app${item.href}`,
            })),
          })}
        </script>
      </Helmet>

      <div className="min-h-screen flex flex-col bg-background">
        <Header />

        <main className="flex-1">
          {/* Page Header */}
          <div className="bg-primary py-8 md:py-12">
            <div className="container mx-auto px-4">
              {/* Breadcrumbs */}
              <nav className="flex items-center gap-2 text-sm text-primary-foreground/70 mb-4">
                {breadcrumbs.map((item, index) => (
                  <span key={item.href} className="flex items-center gap-2">
                    {index > 0 && <ChevronRight className="w-4 h-4" />}
                    <Link to={item.href} className="hover:text-primary-foreground transition-colors">
                      {item.label}
                    </Link>
                  </span>
                ))}
              </nav>

              <h1 className="text-2xl md:text-4xl font-serif font-bold text-primary-foreground mb-2">
                {routeFilters.bhk ? `${routeFilters.bhk} BHK ` : ''}
                {routeFilters.propertyType
                  ? propertyTypes.find((t) => t.value === routeFilters.propertyType)?.label + 's'
                  : 'Properties'}
                {' '}
                {routeFilters.listingType === 'rent' ? 'for Rent' : 'for Sale'}
                {routeFilters.area ? ` in ${routeFilters.area}` : ''}, Nashik
              </h1>
              <p className="text-primary-foreground/70">
                {isLoading ? 'Loading...' : `${filteredProperties.length} properties found`}
              </p>
            </div>
          </div>

          <div className="container mx-auto px-4 py-8">
            {/* Quick Links - Popular Areas */}
            <div className="mb-8">
              <h2 className="text-lg font-semibold text-foreground mb-4">Popular Areas in Nashik</h2>
              <div className="flex flex-wrap gap-2">
                {['Gangapur Road', 'Cidco', 'Panchavati', 'Satpur', 'College Road', 'Deolali', 'Nashik Road', 'Dwarka'].map(
                  (areaName) => (
                    <Link
                      key={areaName}
                      to={`/nashik/${createSlug(areaName)}/properties-for-sale`}
                      className="px-4 py-2 bg-muted hover:bg-primary/10 rounded-full text-sm font-medium text-foreground transition-colors"
                    >
                      {areaName}
                    </Link>
                  )
                )}
              </div>
            </div>

            <div className="flex flex-col lg:flex-row gap-8">
              {/* Sidebar - Quick Filters */}
              <aside className="hidden lg:block w-72 flex-shrink-0">
                <div className="bg-card rounded-xl border border-border p-6 sticky top-24">
                  <h3 className="font-semibold text-foreground mb-4">Browse by Area</h3>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {nashikAreas.slice(0, 30).map((areaName) => (
                      <Link
                        key={areaName}
                        to={`/nashik/${createSlug(areaName)}/properties-for-sale`}
                        className="flex items-center gap-2 py-2 px-3 rounded-lg hover:bg-muted text-sm text-muted-foreground hover:text-foreground transition-colors"
                      >
                        <MapPin className="w-4 h-4" />
                        {areaName}
                      </Link>
                    ))}
                  </div>

                  {/* Sidebar Ad */}
                  <div className="mt-6 pt-6 border-t border-border">
                    <AdBanner variant="square" />
                  </div>
                </div>
              </aside>

              {/* Main Content */}
              <div className="flex-1">
                {/* Sort & View */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <Select value={sortBy} onValueChange={setSortBy}>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Sort by" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="newest">Newest First</SelectItem>
                        <SelectItem value="price-low">Price: Low to High</SelectItem>
                        <SelectItem value="price-high">Price: High to Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="hidden sm:flex border border-border rounded-lg overflow-hidden">
                    <button
                      onClick={() => setViewMode('grid')}
                      className={`p-2 ${viewMode === 'grid' ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:bg-muted'}`}
                    >
                      <Grid className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setViewMode('list')}
                      className={`p-2 ${viewMode === 'list' ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:bg-muted'}`}
                    >
                      <List className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Ad Banner */}
                <AdBanner variant="horizontal" className="mb-6" />

                {/* Properties Grid */}
                {isLoading ? (
                  <div className={`grid gap-6 ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 xl:grid-cols-3' : 'grid-cols-1'}`}>
                    {[1, 2, 3, 4, 5, 6].map((i) => (
                      <div key={i} className="space-y-4">
                        <Skeleton className="h-48 w-full rounded-xl" />
                        <Skeleton className="h-4 w-3/4" />
                        <Skeleton className="h-4 w-1/2" />
                      </div>
                    ))}
                  </div>
                ) : filteredProperties.length > 0 ? (
                  <div className={`grid gap-6 ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 xl:grid-cols-3' : 'grid-cols-1'}`}>
                    {filteredProperties.map((property, index) => (
                      <div
                        key={property.id}
                        className="animate-fade-up"
                        style={{ animationDelay: `${index * 0.05}s` }}
                      >
                        <PropertyCard property={mapToPropertyCard(property)} />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-16">
                    <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                      <Home className="w-8 h-8 text-muted-foreground" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-2">No properties found</h3>
                    <p className="text-muted-foreground mb-4">
                      Be the first to list a property in this area!
                    </p>
                    <Button asChild>
                      <Link to="/post-property">Post Your Property</Link>
                    </Button>
                  </div>
                )}

                {/* SEO Content */}
                <div className="mt-12 bg-muted/50 rounded-xl p-6">
                  <h2 className="text-xl font-semibold text-foreground mb-4">
                    {routeFilters.area ? `Properties in ${routeFilters.area}` : 'Properties in Nashik'}
                  </h2>
                  <p className="text-muted-foreground leading-relaxed">
                    {routeFilters.area ? (
                      <>
                        Looking for property in {routeFilters.area}, Nashik? NashikGharMitra offers the best deals on
                        flats, apartments, houses, and plots in {routeFilters.area}. Whether you're looking to buy or rent,
                        find verified listings with photos, contact details, and transparent pricing. Connect directly
                        with property owners and save on brokerage.
                      </>
                    ) : (
                      <>
                        NashikGharMitra is Nashik's trusted property platform for finding your dream home. Browse through
                        verified listings of apartments, houses, villas, plots, and commercial spaces across all areas
                        of Nashik District. From Gangapur Road to Cidco, Panchavati to Deolali - find the best property
                        deals with photos, amenities, and direct owner contact.
                      </>
                    )}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default NashikProperties;
