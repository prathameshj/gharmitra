import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { User, Mail, Phone, Edit3, Save, Building2, Rocket, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface UserProperty {
  id: string;
  title: string;
  city: string;
  price: number;
  is_boosted: boolean;
  is_featured: boolean;
  created_at: string;
}

const Profile = () => {
  const navigate = useNavigate();
  const { user, profile, loading, refreshProfile, signOut } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [properties, setProperties] = useState<UserProperty[]>([]);
  const [formData, setFormData] = useState({
    full_name: '',
    phone: '',
  });

  useEffect(() => {
    if (!loading && !user) {
      navigate('/login');
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (profile) {
      setFormData({
        full_name: profile.full_name || '',
        phone: profile.phone || '',
      });
    }
  }, [profile]);

  useEffect(() => {
    const fetchProperties = async () => {
      if (user) {
        const { data, error } = await supabase
          .from('properties')
          .select('id, title, city, price, is_boosted, is_featured, created_at')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false });

        if (!error && data) {
          setProperties(data);
        }
      }
    };

    fetchProperties();
  }, [user]);

  const handleSave = async () => {
    if (!user) return;

    const { error } = await supabase
      .from('profiles')
      .update({
        full_name: formData.full_name,
        phone: formData.phone,
      })
      .eq('user_id', user.id);

    if (error) {
      toast.error('Failed to update profile');
    } else {
      toast.success('Profile updated successfully!');
      setIsEditing(false);
      refreshProfile();
    }
  };

  const handleBoostRequest = async (propertyId: string) => {
    if (!user) return;

    const { error } = await supabase.from('boost_requests').insert({
      user_id: user.id,
      property_id: propertyId,
      message: 'I would like to boost this property',
    });

    if (error) {
      toast.error('Failed to submit boost request');
    } else {
      toast.success('Boost request submitted! We will contact you soon.');
    }
  };

  const handleDeleteProperty = async (propertyId: string) => {
    if (!confirm('Are you sure you want to delete this property?')) return;

    const { error } = await supabase.from('properties').delete().eq('id', propertyId);

    if (error) {
      toast.error('Failed to delete property');
    } else {
      toast.success('Property deleted successfully!');
      setProperties(properties.filter(p => p.id !== propertyId));
    }
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/');
  };

  const formatPrice = (price: number) => {
    if (price >= 10000000) {
      return `₹${(price / 10000000).toFixed(2)} Cr`;
    }
    if (price >= 100000) {
      return `₹${(price / 100000).toFixed(2)} Lac`;
    }
    return `₹${price.toLocaleString('en-IN')}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1 py-8">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Profile Card */}
            <div className="lg:col-span-1">
              <div className="bg-card rounded-2xl border border-border p-6 shadow-lg">
                <div className="text-center mb-6">
                  <div className="w-24 h-24 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <User className="w-12 h-12 text-primary" />
                  </div>
                  <h2 className="text-xl font-serif font-bold text-foreground">
                    {profile?.full_name || 'User'}
                  </h2>
                  <p className="text-muted-foreground text-sm">{user?.email}</p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">Full Name</label>
                    {isEditing ? (
                      <Input
                        value={formData.full_name}
                        onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                      />
                    ) : (
                      <p className="text-foreground">{profile?.full_name || 'Not set'}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">Email</label>
                    <div className="flex items-center gap-2 text-foreground">
                      <Mail className="w-4 h-4 text-muted-foreground" />
                      {user?.email}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">Phone</label>
                    {isEditing ? (
                      <Input
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      />
                    ) : (
                      <div className="flex items-center gap-2 text-foreground">
                        <Phone className="w-4 h-4 text-muted-foreground" />
                        {profile?.phone || 'Not set'}
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-6 flex flex-col gap-3">
                  {isEditing ? (
                    <div className="flex gap-2">
                      <Button onClick={handleSave} className="flex-1">
                        <Save className="w-4 h-4 mr-2" />
                        Save
                      </Button>
                      <Button variant="outline" onClick={() => setIsEditing(false)} className="flex-1">
                        Cancel
                      </Button>
                    </div>
                  ) : (
                    <Button variant="outline" onClick={() => setIsEditing(true)}>
                      <Edit3 className="w-4 h-4 mr-2" />
                      Edit Profile
                    </Button>
                  )}
                  <Button variant="destructive" onClick={handleLogout}>
                    Logout
                  </Button>
                </div>
              </div>
            </div>

            {/* Properties */}
            <div className="lg:col-span-2">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-serif font-bold text-foreground">My Properties</h2>
                <Link to="/post-property">
                  <Button>
                    <Building2 className="w-4 h-4 mr-2" />
                    Add Property
                  </Button>
                </Link>
              </div>

              {properties.length === 0 ? (
                <div className="bg-card rounded-2xl border border-border p-12 text-center">
                  <Building2 className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">No properties yet</h3>
                  <p className="text-muted-foreground mb-4">Start by adding your first property listing</p>
                  <Link to="/post-property">
                    <Button>Post Property</Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-4">
                  {properties.map((property) => (
                    <div
                      key={property.id}
                      className={`bg-card rounded-xl border p-4 transition-all ${
                        property.is_boosted 
                          ? 'border-accent shadow-lg ring-2 ring-accent/20' 
                          : 'border-border'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <Link
                              to={`/property/${property.id}`}
                              className="font-semibold text-foreground hover:text-primary transition-colors"
                            >
                              {property.title}
                            </Link>
                            {property.is_boosted && (
                              <Badge className="bg-accent text-accent-foreground">Boosted</Badge>
                            )}
                            {property.is_featured && (
                              <Badge className="bg-primary text-primary-foreground">Featured</Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{property.city}</p>
                          <p className="text-lg font-bold text-primary">{formatPrice(property.price)}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          {!property.is_boosted && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleBoostRequest(property.id)}
                            >
                              <Rocket className="w-4 h-4 mr-1" />
                              Boost
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteProperty(property.id)}
                            className="text-destructive hover:bg-destructive/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Profile;
