import { Helmet } from 'react-helmet-async';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import HeroSection from '@/components/home/HeroSection';
import FeaturedProperties from '@/components/home/FeaturedProperties';
import PropertyCategories from '@/components/home/PropertyCategories';
import RecentProperties from '@/components/home/RecentProperties';
import WhyChooseUs from '@/components/home/WhyChooseUs';
import CTASection from '@/components/home/CTASection';
import AdBanner from '@/components/home/AdBanner';

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>NashikGharMitra | Best Property Portal in Nashik - Buy, Sell, Rent</title>
        <meta name="description" content="Find the best real estate deals in Nashik. Buy, sell, or rent flats, houses, villas, plots, and commercial shops in Nashik with NashikGharMitra. Verified listings, zero brokerage." />
        <meta name="keywords" content="property in nashik, real estate nashik, buy flat in nashik, rent house nashik, plots in nashik, NashikGharMitra" />
        <meta property="og:title" content="NashikGharMitra | Nashik's Trusted Property Portal" />
        <meta property="og:description" content="Nashik's #1 property portal. Connect directly with owners for flats, houses, and plots in Nashik." />
        <meta property="og:image" content="https://nashikgharmitra.vercel.app/nashik-ghar-mitra-logo.png" />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="NashikGharMitra | Property in Nashik" />
        <meta name="twitter:description" content="Nashik's #1 property portal. Connect directly with owners for flats, houses, and plots in Nashik." />
        <meta name="twitter:image" content="https://nashikgharmitra.vercel.app/nashik-ghar-mitra-logo.png" />
        <link rel="canonical" href="https://nashikgharmitra.vercel.app/" />
      </Helmet>
      <Header />
      <main className="flex-1">
        <HeroSection />
        
        {/* Ad Banner */}
        <div className="container mx-auto px-4 py-6">
          <AdBanner variant="horizontal" />
        </div>

        <FeaturedProperties />
        <PropertyCategories />
        <RecentProperties />
        <WhyChooseUs />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
