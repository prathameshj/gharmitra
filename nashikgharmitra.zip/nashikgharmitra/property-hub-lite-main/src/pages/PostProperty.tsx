import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { Building2, Home, Castle, LandPlot, Store, Briefcase, ShoppingCart, Upload, CheckCircle, X, Image } from 'lucide-react';
import { cities } from '@/data/mockProperties';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { uploadToCloudinary, validateImage, getThumbnailUrl } from '@/services/cloudinaryService';

const propertyTypeOptions = [
  { id: 'apartment', label: 'Apartment', icon: Building2 },
  { id: 'house', label: 'House', icon: Home },
  { id: 'villa', label: 'Villa', icon: Castle },
  { id: 'plot', label: 'Plot', icon: LandPlot },
  { id: 'shop', label: 'Shop', icon: ShoppingCart },
  { id: 'commercial', label: 'Commercial', icon: Store },
  { id: 'office', label: 'Office', icon: Briefcase },
];

const amenitiesList = [
  'Swimming Pool', 'Gym', 'Parking', 'Security', 'Power Backup', 'Lift',
  'Garden', 'Club House', 'Play Area', 'CCTV', 'Intercom', 'Water Supply'
];

const PostProperty = () => {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [step, setStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [uploadingImages, setUploadingImages] = useState(false);
  const [selectedImages, setSelectedImages] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [formData, setFormData] = useState({
    type: '',
    propertyType: '',
    title: '',
    description: '',
    price: '',
    area: '',
    bedrooms: '',
    bathrooms: '',
    city: '',
    location: '',
    pincode: '',
    amenities: [] as string[],
  });

  useEffect(() => {
    if (!loading && !user) {
      toast.error('Please login to post a property');
      navigate('/login');
    }
  }, [user, loading, navigate]);

  const handlePropertyTypeSelect = (type: string) => {
    setFormData({ ...formData, propertyType: type });
  };

  const handleAmenityToggle = (amenity: string) => {
    const current = formData.amenities;
    if (current.includes(amenity)) {
      setFormData({ ...formData, amenities: current.filter((a) => a !== amenity) });
    } else {
      setFormData({ ...formData, amenities: [...current, amenity] });
    }
  };


  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    // Limit to 3 photos max
    const newFiles = Array.from(files).slice(0, 3 - selectedImages.length);
    
    if (selectedImages.length + newFiles.length > 3) {
      toast.error('Maximum 3 photos allowed per listing');
      return;
    }
    
    // Validate files with Cloudinary validation
    const validFiles = newFiles.filter(file => {
      const validation = validateImage(file);
      if (!validation.valid) {
        toast.error(`${file.name}: ${validation.error}`);
        return false;
      }
      return true;
    });

    // Store files for upload
    setSelectedImages(prev => [...prev, ...validFiles]);
    
    // Create previews
    validFiles.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreviews(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRemoveImage = (index: number) => {
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
    setImagePreviews(prev => prev.filter((_, i) => i !== index));
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    const files = e.dataTransfer.files;
    if (!files) return;

    // Limit to 3 photos max
    const newFiles = Array.from(files).slice(0, 3 - selectedImages.length);
    
    if (selectedImages.length + newFiles.length > 3) {
      toast.error('Maximum 3 photos allowed per listing');
      return;
    }
    
    const validFiles = newFiles.filter(file => {
      const validation = validateImage(file);
      if (!validation.valid) {
        toast.error(`${file.name}: ${validation.error}`);
        return false;
      }
      return true;
    });

    setSelectedImages(prev => [...prev, ...validFiles]);
    
    validFiles.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreviews(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const uploadImages = async (): Promise<string[]> => {
    if (!user || selectedImages.length === 0) return [];
    
    setUploadingImages(true);
    const uploadedUrls: string[] = [];

    try {
      for (const file of selectedImages) {
        const result = await uploadToCloudinary(file, `nashik_properties/${user.id}`);
        
        if (result.success && result.url) {
          uploadedUrls.push(result.url);
          toast.success(`Image uploaded (${result.size ? (result.size / 1024).toFixed(0) : '?'} KB)`);
        } else {
          toast.error(`Failed to upload ${file.name}: ${result.error}`);
        }
      }
    } finally {
      setUploadingImages(false);
    }

    return uploadedUrls;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast.error('Please login to post a property');
      navigate('/login');
      return;
    }

    setSubmitting(true);

    // Upload images first
    const imageUrls = await uploadImages();

    const { error } = await supabase.from('properties').insert({
      user_id: user.id,
      title: formData.title,
      description: formData.description || null,
      property_type: formData.propertyType,
      listing_type: formData.type,
      price: parseFloat(formData.price),
      bedrooms: formData.bedrooms ? parseInt(formData.bedrooms) : null,
      bathrooms: formData.bathrooms ? parseInt(formData.bathrooms) : null,
      area: formData.area ? parseFloat(formData.area) : null,
      address: formData.location,
      city: formData.city,
      pincode: formData.pincode || null,
      amenities: formData.amenities.length > 0 ? formData.amenities : null,
      images: imageUrls.length > 0 ? imageUrls : null,
    });

    setSubmitting(false);

    if (error) {
      toast.error('Failed to post property. Please try again.');
    } else {
      toast.success('Property posted successfully!');
      navigate('/profile');
    }
  };

  const isStep1Valid = formData.type && formData.propertyType;
  const isStep2Valid = formData.title && formData.price && formData.area && formData.city && formData.location;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1 py-8 md:py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            {/* Header */}
            <div className="text-center mb-10">
              <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">
                Post Your Property
              </h1>
              <p className="text-muted-foreground">
                List your property for free and connect with thousands of potential buyers/tenants.
              </p>
            </div>

            {/* Progress Steps */}
            <div className="flex items-center justify-center gap-4 mb-10">
              {[1, 2, 3].map((s) => (
                <div key={s} className="flex items-center gap-2">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                      step >= s
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {step > s ? <CheckCircle className="w-5 h-5" /> : s}
                  </div>
                  {s < 3 && (
                    <div className={`w-16 h-1 rounded-full ${step > s ? 'bg-primary' : 'bg-muted'}`} />
                  )}
                </div>
              ))}
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="bg-card rounded-2xl border border-border p-6 md:p-8">
              {/* Step 1: Property Type */}
              {step === 1 && (
                <div className="space-y-6 animate-fade-in">
                  <h2 className="text-xl font-semibold text-foreground">Property Details</h2>
                  
                  {/* Listing Type */}
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-3">I want to</label>
                    <div className="grid grid-cols-2 gap-3">
                      {['Sell', 'Rent'].map((type) => (
                        <button
                          key={type}
                          type="button"
                          onClick={() => setFormData({ ...formData, type: type.toLowerCase() === 'sell' ? 'sale' : 'rent' })}
                          className={`p-4 rounded-xl border-2 text-center font-medium transition-all ${
                            formData.type === (type.toLowerCase() === 'sell' ? 'sale' : 'rent')
                              ? 'border-primary bg-primary/5 text-primary'
                              : 'border-border hover:border-primary/50'
                          }`}
                        >
                          {type} Property
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Property Type */}
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-3">Property Type</label>
                    <div className="grid grid-cols-3 gap-3">
                      {propertyTypeOptions.map((option) => (
                        <button
                          key={option.id}
                          type="button"
                          onClick={() => handlePropertyTypeSelect(option.id)}
                          className={`p-4 rounded-xl border-2 text-center transition-all ${
                            formData.propertyType === option.id
                              ? 'border-primary bg-primary/5 text-primary'
                              : 'border-border hover:border-primary/50'
                          }`}
                        >
                          <option.icon className="w-6 h-6 mx-auto mb-2" />
                          <span className="text-sm font-medium">{option.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <Button
                    type="button"
                    onClick={() => setStep(2)}
                    disabled={!isStep1Valid}
                    className="w-full"
                    size="lg"
                  >
                    Continue
                  </Button>
                </div>
              )}

              {/* Step 2: Property Info */}
              {step === 2 && (
                <div className="space-y-6 animate-fade-in">
                  <h2 className="text-xl font-semibold text-foreground">Property Information</h2>
                  
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Property Title</label>
                    <Input
                      placeholder="e.g., Spacious 3BHK Apartment with Sea View"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">
                        Price (₹) {formData.type === 'rent' && '/ month'}
                      </label>
                      <Input
                        type="number"
                        placeholder="Enter price"
                        value={formData.price}
                        onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Area (sq.ft)</label>
                      <Input
                        type="number"
                        placeholder="Enter area"
                        value={formData.area}
                        onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                      />
                    </div>
                  </div>

                  {!['plot', 'commercial'].includes(formData.propertyType) && (
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">Bedrooms</label>
                        <Select
                          value={formData.bedrooms}
                          onValueChange={(value) => setFormData({ ...formData, bedrooms: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            {[1, 2, 3, 4, 5, '5+'].map((n) => (
                              <SelectItem key={n} value={String(n)}>{n} BHK</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">Bathrooms</label>
                        <Select
                          value={formData.bathrooms}
                          onValueChange={(value) => setFormData({ ...formData, bathrooms: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            {[1, 2, 3, 4, '4+'].map((n) => (
                              <SelectItem key={n} value={String(n)}>{n}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Area</label>
                      <Select
                        value={formData.city}
                        onValueChange={(value) => setFormData({ ...formData, city: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select Area" />
                        </SelectTrigger>
                        <SelectContent>
                          {cities.map((city) => (
                            <SelectItem key={city} value={city}>{city}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Locality/Address</label>
                      <Input
                        placeholder="e.g., Near Dwarka Circle"
                        value={formData.location}
                        onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <Button type="button" variant="outline" onClick={() => setStep(1)} className="flex-1" size="lg">
                      Back
                    </Button>
                    <Button
                      type="button"
                      onClick={() => setStep(3)}
                      disabled={!isStep2Valid}
                      className="flex-1"
                      size="lg"
                    >
                      Continue
                    </Button>
                  </div>
                </div>
              )}

              {/* Step 3: Additional Details */}
              {step === 3 && (
                <div className="space-y-6 animate-fade-in">
                  <h2 className="text-xl font-semibold text-foreground">Additional Details</h2>
                  
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Description</label>
                    <Textarea
                      placeholder="Describe your property in detail..."
                      rows={4}
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-3">Amenities</label>
                    <div className="flex flex-wrap gap-2">
                      {amenitiesList.map((amenity) => (
                        <button
                          key={amenity}
                          type="button"
                          onClick={() => handleAmenityToggle(amenity)}
                          className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                            formData.amenities.includes(amenity)
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                          }`}
                        >
                          {amenity}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-3">Upload Photos</label>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleImageSelect}
                      className="hidden"
                    />
                    
                    {/* Image Previews */}
                    {imagePreviews.length > 0 && (
                      <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 mb-4">
                        {imagePreviews.map((preview, index) => (
                          <div key={index} className="relative aspect-square rounded-lg overflow-hidden border border-border">
                            <img src={preview} alt={`Preview ${index + 1}`} className="w-full h-full object-cover" />
                            <button
                              type="button"
                              onClick={() => handleRemoveImage(index)}
                              className="absolute top-1 right-1 w-6 h-6 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center hover:bg-destructive/90"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    {selectedImages.length < 3 && (
                      <div 
                        onClick={() => fileInputRef.current?.click()}
                        onDrop={handleDrop}
                        onDragOver={(e) => e.preventDefault()}
                        className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-primary/50 transition-colors cursor-pointer"
                      >
                        <Upload className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                        <p className="text-sm text-muted-foreground">
                          Drag & drop photos here or click to browse
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Max 3 photos (auto-compressed) • {selectedImages.length}/3 selected
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="flex gap-3">
                    <Button type="button" variant="outline" onClick={() => setStep(2)} className="flex-1" size="lg">
                      Back
                    </Button>
                    <Button type="submit" variant="accent" className="flex-1" size="lg" disabled={submitting || uploadingImages}>
                      {submitting || uploadingImages ? (uploadingImages ? 'Uploading Images...' : 'Posting...') : 'Post Property'}
                    </Button>
                  </div>
                </div>
              )}
            </form>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default PostProperty;